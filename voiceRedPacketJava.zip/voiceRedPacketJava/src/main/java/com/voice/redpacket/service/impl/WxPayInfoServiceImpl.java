package com.voice.redpacket.service.impl;

import com.voice.redpacket.dao.VoiceRedPacketMapper;
import com.voice.redpacket.dao.WxPayInfoMapper;
import com.voice.redpacket.domain.VoiceRedPacket;
import com.voice.redpacket.domain.WxPayInfo;
import com.voice.redpacket.service.IWxPayInfoService;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
@Service
public class WxPayInfoServiceImpl implements IWxPayInfoService {
    @Resource
    private WxPayInfoMapper wxPayInfoMapper;
    @Resource
    private VoiceRedPacketMapper voiceRedPacketMapper;


    @Override
    public void save(WxPayInfo wxPayInfo) {
        wxPayInfoMapper.insertSelective(wxPayInfo);
    }

    @Override
    public int update(WxPayInfo wxPayInfo) {
        return wxPayInfoMapper.updateByPrimaryKeySelective(wxPayInfo);
    }

    @Override
    public WxPayInfo findByPayId(Long payId) {
        return wxPayInfoMapper.selectByPrimaryKey(payId);
    }

    @Override
    public boolean hasPaid(int packetId) {
        int num = wxPayInfoMapper.hasPaid(packetId);
        return num > 0;
    }

    @Override
    public WxPayInfo findByTradeNo(String outTradeNo) {
        return wxPayInfoMapper.findByTradeNo(outTradeNo);
    }

    @Override
    public WxPayInfo findByPacketId(Integer packetId) {
        return wxPayInfoMapper.findByPacketId(packetId);
    }

    @Override
    public void updateWhenPaySuccess(WxPayInfo wxPayInfo) {
        wxPayInfoMapper.updateByPrimaryKeySelective(wxPayInfo);

        VoiceRedPacket tmp = new VoiceRedPacket();
        tmp.setPayId(wxPayInfo.getPayId());
        List<VoiceRedPacket> packetList = voiceRedPacketMapper.findListByEntity(tmp);
        if(CollectionUtils.isNotEmpty(packetList)){
            VoiceRedPacket voiceRedPacket = packetList.get(0);
            voiceRedPacket.setPayStatus((short) 1);
            voiceRedPacketMapper.updateByPrimaryKeySelective(voiceRedPacket);
        }
    }
}
