package com.voice.redpacket.util;


import com.voice.redpacket.constant.Constant;

import java.util.ArrayList;
import java.util.List;

public class MoneyUtil {
	/**
	 * 生成随机红包集合
	 * @param totalMoney
	 * @param num
     * @return
     */
	public static List<Integer> generateRandomMoneys(int totalMoney, int num){
		List<Integer> resultList = new ArrayList<>();
		while(num>0){
			int randomMoney = getRandomMoney(totalMoney, num);
			resultList.add(randomMoney);
			num --;
			totalMoney -= randomMoney;
		}
		return resultList;
	}
	/**
	 * 获取单个随机红包金额
	 * @param totalMoney 总余额(分)
	 * @param num 人数
	 * @return
	 */
	public static int getRandomMoney(int totalMoney,int num){
		return random(totalMoney,1,totalMoney,num);
	}

	/**
	 * 随机金额
	 * @param money 总钱数
	 * @param minS 最小值
	 * @param maxS 最大值
	 * @param count 人数
     * @return
     */
	private static int random(int money, int minS, int maxS, int count) {
		//红包数量为1，直接返回金额
		if (count == 1) {
			return money;
		}
		//如果最大金额和最小金额相等，直接返回金额
		if (minS == maxS) {
			return minS;
		}
		int max = maxS > money ? money : maxS;
		//分配红包正确情况，允许红包的最大值
		int maxY = money - (count - 1) * minS;
		//分配红包正确情况，允许红包的最小值
		int minY = money - (count - 1) * maxS;
		//随机产生红包的最小值
		int min = minY > minS ? minY : minS;
		//随机产生红包最大值
		max = maxY < max ? maxY : max;
		//随机产生一个红包
		return (int)Math.rint(Math.random() * (max - min) + min);
	}
	
	public static void main(String[] args) {
		int totalMoney = 100;
		int num = 5;
		
		while(num>0){
			int randomMoney = getRandomMoney(totalMoney, num);
			System.out.println(randomMoney);
			num --;
			totalMoney -= randomMoney;
		}
	}


	/**
	 * 保存某红包生成的随机金额列表到redis缓存
	 * @param packetId
	 * @param randomMoneys
	 * @param seconds
     */
	public static void setRandomMoneysToRedis(int packetId, List<Integer> randomMoneys,int seconds) {
		String[] randomMoneysArray = new String[randomMoneys.size()];
		for(int i=0;i<randomMoneysArray.length;i++){
			randomMoneysArray[i] = String.valueOf(randomMoneys.get(i));
		}
		JedisUtil.lpush(Constant.VOICE_REDPACKET_RANDOM_MONEYS+packetId,seconds, randomMoneysArray);
	}

	/**
	 * 从redis中获取某红包的一个随机金额
	 * @param packetId
	 * @return
     */
	public static String getRandomMoneyFromRedis(int packetId){
		return JedisUtil.rpop(Constant.VOICE_REDPACKET_RANDOM_MONEYS + packetId);
	}

}
