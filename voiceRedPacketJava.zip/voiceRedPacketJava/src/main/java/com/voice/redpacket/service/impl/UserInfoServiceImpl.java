package com.voice.redpacket.service.impl;

import com.voice.redpacket.dao.UserAmountRecordsMapper;
import com.voice.redpacket.dao.UserInfoMapper;
import com.voice.redpacket.domain.UserAmountRecords;
import com.voice.redpacket.domain.UserInfo;
import com.voice.redpacket.service.IUserInfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
@Service
public class UserInfoServiceImpl implements IUserInfoService {
    @Resource
    private UserInfoMapper userInfoMapper;
    @Resource
    private UserAmountRecordsMapper userAmountRecordsMapper;

    @Override
    public void save(UserInfo userInfo) {
        userInfoMapper.insertSelective(userInfo);
    }

    @Override
    public UserInfo getUserInfoByUnionId(String unionId) {
        return userInfoMapper.selectByUnionId(unionId);
    }

    @Override
    public UserInfo getUserInfoByOpenId(String openId) {
        return userInfoMapper.selectByPrimaryKey(openId);
    }

    @Override
    public void updateSelective(UserInfo userInfo) {
        userInfoMapper.updateByPrimaryKeySelective(userInfo);
    }

    @Override
    public List<UserAmountRecords> findUserAmountRecords(String openId) {
        return userAmountRecordsMapper.findUserAmountRecords(openId);
    }

}
