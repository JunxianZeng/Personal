package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

import vo.AccountVo;

public class LookInfoUI extends JFrame implements MouseListener{
	private JLabel lblQQcode,lblnickName,lblAge,lblBg;
	private JLabel lblSex,lblNation,lblStar,lblBlood;
	private JLabel lblRemark,lblHobit,lblHeadImg;
	public LookInfoUI(){}
	public LookInfoUI(AccountVo myInfo){
		super("�޸ĸ����û�����");
		setIconImage(new ImageIcon("images/tubiao.jpg").getImage());
		lblBg = new JLabel(new ImageIcon("images/bgreg5.jpg"));
		add(lblBg);
		lblBg.setLayout(null);
		JLabel title = new JLabel("��������",SwingConstants.CENTER);
		title.setFont(new Font("����",Font.BOLD,36));
		title.setForeground(Color.RED);
		title.setBounds(0,30,260,40);
		lblBg.add(title);
		lblQQcode = new JLabel("QQ����:"+myInfo.getQqCode(),SwingConstants.RIGHT);
		lblnickName = new JLabel("�ǳ�:"+myInfo.getNickName(),SwingConstants.RIGHT);
		lblHeadImg = new JLabel(new ImageIcon(myInfo.getHeadImg()));
		lblAge = new JLabel("����:"+myInfo.getAge(),SwingConstants.RIGHT);
		lblSex = new JLabel("�Ա�:"+myInfo.getSex(),SwingConstants.RIGHT);
		lblNation = new JLabel("����:"+myInfo.getNation(),SwingConstants.RIGHT);
		lblStar = new JLabel("����:"+myInfo.getStar(),SwingConstants.RIGHT);
		lblBlood = new JLabel("Ѫ��:"+myInfo.getBlood()+"��",SwingConstants.RIGHT);
		lblHobit = new JLabel("����:"+myInfo.getHobit(),SwingConstants.CENTER);
		lblRemark = new JLabel("��ע:"+myInfo.getRemark(),SwingConstants.CENTER);
		
		
		
		lblQQcode.setBounds(0, 100, 100, 20);
		lblnickName.setBounds(0, 140, 100, 20);
		
		lblHeadImg.setBounds(280, 100, 80, 60);
		
		lblAge.setBounds(0, 180, 100, 20);
		lblSex.setBounds(280, 180, 80, 20);
		
		lblNation.setBounds(0, 220, 100, 20);
		lblStar.setBounds(280, 220, 80, 20);
		
		lblBlood.setBounds(0, 260, 100, 20);
		lblHobit.setBounds(0, 300, 300, 20);

		lblRemark.setBounds(0, 340, 300, 20);
		
		lblBg.add(lblQQcode);
		lblBg.add(lblnickName);
		lblBg.add(lblHeadImg);
		lblBg.add(lblAge);
		lblBg.add(lblSex);
		lblBg.add(lblNation);
		lblBg.add(lblStar);
		lblBg.add(lblBlood);
		lblBg.add(lblHobit);
		lblBg.add(lblRemark);
		addMouseListener(this);
		//���ر�����
		setUndecorated(true);
		setResizable(false);
		setSize(420, 380);
		setVisible(true);
		setLocationRelativeTo(null);
		//�رմ��ڣ����˳�Ӧ�ó���
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}

	public static void main(String[] args) {
		new LookInfoUI();
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		dispose();
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
