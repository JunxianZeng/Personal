package com.voice.redpacket;

import com.voice.redpacket.constant.Constant;
import com.voice.redpacket.domain.UserInfo;
import com.voice.redpacket.service.IUserInfoService;
import com.voice.redpacket.util.PayUtil;
import org.junit.Test;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ZhaoYuJie on 2018/2/9.
 */
public class RedPacketTest extends BaseTest {
    @Resource
    private IUserInfoService userInfoService;

    @Test
    public void nickNameEmojiTest(){
        UserInfo userInfo = new UserInfo();
        userInfo.setOpenId("ooJ_S5EsoPMVT25VQ7JRFN7uLF4Q");
        userInfo.setNickName("摩西\uD83C\uDF38");
        userInfoService.updateSelective(userInfo);
    }

    @Test
    public void signTest(){
        HashMap resultMap = new HashMap();
        resultMap.put("is_subscribe","N");
        resultMap.put("appid","wx08cbbca50fa0b086");
        resultMap.put("fee_type","CNY");
        resultMap.put("nonce_str","ivoc47y00d3w4uxrfpmn6gx93ryme7cm");
        resultMap.put("out_trade_no","14988548222018021315300830242766");
        resultMap.put("transaction_id","4200000077201802132137746481");
        resultMap.put("trade_type","JSAPI");
        resultMap.put("result_code","SUCCESS");
        resultMap.put("sign","B46416A25A7ECB7FAFC0FBADF811C9FD");
        resultMap.put("mch_id","1498854822");
        resultMap.put("total_fee","1");
        resultMap.put("time_end","20180213153122");
        resultMap.put("openid","ooJ_S5EsoPMVT25VQ7JRFN7uLF4Q");
        resultMap.put("bank_type","CFT");
        resultMap.put("return_code","SUCCESS");
        resultMap.put("cash_fee","1");

        // 除去数组中的空值和签名参数
        Map<String, String> sPara = PayUtil.paraFilter(resultMap);
        String prestr = PayUtil.createLinkString(sPara); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
        String key = "&key="+ Constant.WX_XIAOCHENGXU_MCH_KEY; // 商户支付密钥
        //MD5运算生成签名
        String resultSign = PayUtil.sign(prestr, key, "utf-8").toUpperCase();

        System.out.println(resultSign);

    }

}
