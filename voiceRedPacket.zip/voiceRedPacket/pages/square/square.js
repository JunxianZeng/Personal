const app = getApp()
const util = require('../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    optionsHide: true,
    showOption: '最大金额',
    showValue:'1',
    rotate: false,
    voiceRedPacketList:[]
  },

  onLoad: function (options){
    wx.showShareMenu({
      withShareTicket: true
    })
  },
  /**
   * tabBar页面用onLoad不好使，只有第一次进入有效。所以改用onShow
   */
  onShow: function () {
    console.log("onShow.....")
    this.search();

  },
  //点击选择类型
  clickSelect: function () {
    var optionsHide = this.data.optionsHide;
    if (optionsHide == true) {
      this.setData({
        rotate: true,
        optionsHide: false,
      })
    } else {
      this.setData({
        rotate: false,
        optionsHide: true,
      })
    }
  },
  //点击切换
  selectType: function (e) {
    this.setData({
      showOption: e.target.dataset.text,
      showValue: e.target.dataset.value,
      optionsHide: true,
      rotate: false,
    })
    this.search();
  },
  //查询广场红包列表
  search: function(){
    var that = this;
    wx.request({
      url: app.globalData.baseUrl + 'getPublicPacketList.htm?sortType=' + that.data.showValue,
      success: function(res){
        for (var i = 0; i < res.data.voiceRedPacketList.length; i++) {
          res.data.voiceRedPacketList[i].createTime = util.formatSimpleTime(new Date(res.data.voiceRedPacketList[i].createTime.time));
          res.data.voiceRedPacketList[i].fee = (res.data.voiceRedPacketList[i].fee / 100).toFixed(2);
          var nickName = res.data.voiceRedPacketList[i].nickName;
          if (nickName.length > 8){
            nickName = nickName.substr(0, 8)+"...";
          }
          res.data.voiceRedPacketList[i].nickName = nickName;
        }
        that.setData({
          voiceRedPacketList: res.data.voiceRedPacketList
        })
      }
    })
  },
  toPacketPage: function (e) {
    var packetId = e.currentTarget.dataset.packetid;
    var packetType = e.currentTarget.dataset.packettype;
    if (packetType == 1) { //语音口令
      wx.navigateTo({
        url: '../voice/voice?packetId=' + packetId
      })
    } else if (packetType == 2) { //你问我答
      wx.navigateTo({
        url: '../answer/answer?packetId=' + packetId
      })
    }

  },
  onShareAppMessage: function (res) {
    var that = this;
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '快来领取语音红包',
      path: '/pages/square/square',
      success: function (res) {
        // 转发成功
        console.log("转发成功")
        wx.showModal({
          content: '转发成功',
          showCancel: false
        })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败")
      }
    }
  }


})