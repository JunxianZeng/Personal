package com.voice.redpacket.service.impl;

import com.voice.redpacket.constant.Constant;
import com.voice.redpacket.dao.PacketDrawRelationMapper;
import com.voice.redpacket.dao.UserAmountRecordsMapper;
import com.voice.redpacket.dao.UserInfoMapper;
import com.voice.redpacket.dao.VoiceRedPacketMapper;
import com.voice.redpacket.domain.PacketDrawRelation;
import com.voice.redpacket.domain.UserAmountRecords;
import com.voice.redpacket.domain.UserInfo;
import com.voice.redpacket.domain.VoiceRedPacket;
import com.voice.redpacket.service.IVoiceRedPacketService;
import com.voice.redpacket.util.MoneyUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
@Service
public class VoiceRedPacketServiceImpl implements IVoiceRedPacketService {
    @Resource
    private VoiceRedPacketMapper voiceRedPacketMapper;
	@Resource
	private PacketDrawRelationMapper packetDrawRelationMapper;
	@Resource
	private UserInfoMapper userInfoMapper;
	@Resource
	private UserAmountRecordsMapper userAmountRecordsMapper;

	@Override
	public void createVoice(VoiceRedPacket voiceRedPacket) {
		if(voiceRedPacket.getPayType() == 0 && voiceRedPacket.getType()==1){ //余额支付
			UserInfo tmp = new UserInfo();
			tmp.setOpenId(voiceRedPacket.getOpenId());
			tmp.setAmount(-voiceRedPacket.getFee());
			userInfoMapper.addAmount(tmp);

			UserInfo persistUserInfo = userInfoMapper.selectByPrimaryKey(tmp.getOpenId());
			UserAmountRecords userAmountRecords = new UserAmountRecords();
			userAmountRecords.setOpenId(tmp.getOpenId());
			userAmountRecords.setCurAmount(persistUserInfo.getAmount());
			userAmountRecords.setChangeAmount(tmp.getAmount());
			userAmountRecords.setOperType((short) 2);
			userAmountRecords.setRemarks("发红包扣减余额");
			userAmountRecordsMapper.insertSelective(userAmountRecords);
		}
		voiceRedPacketMapper.insertSelective(voiceRedPacket);
		List<Integer> randomMoneys = MoneyUtil.generateRandomMoneys(voiceRedPacket.getFee(), voiceRedPacket.getNum());
		MoneyUtil.setRandomMoneysToRedis(voiceRedPacket.getId(),randomMoneys, Constant.VOICE_REDPACKET_EXPIRYDATE);
	}

	@Override
	public VoiceRedPacket getVoiceRedPacket(int packetId) {
		return voiceRedPacketMapper.selectByPrimaryKey(packetId);
	}

	@Override
	public int draw(VoiceRedPacket voiceRedPacket, String openId, String uuid, long duration) {
		String randomMoney = MoneyUtil.getRandomMoneyFromRedis(voiceRedPacket.getId());
		if(StringUtils.isBlank(randomMoney)){ //无钱可领了
			return 0;
		}else{
			int drawFee = Integer.valueOf(randomMoney);

			voiceRedPacketMapper.draw(voiceRedPacket);

			PacketDrawRelation packetDrawRelation = new PacketDrawRelation();
			packetDrawRelation.setId(uuid);
			packetDrawRelation.setOpenId(openId);
			packetDrawRelation.setPacketId(voiceRedPacket.getId());
			packetDrawRelation.setDrawFee(drawFee);
			packetDrawRelation.setDrawTime(new Date());
			packetDrawRelation.setDuration(duration);
			packetDrawRelationMapper.insertSelective(packetDrawRelation);

			UserInfo userInfo = new UserInfo();
			userInfo.setOpenId(openId);
			userInfo.setAmount(drawFee);
			userInfoMapper.addAmount(userInfo);

			UserInfo persistUserInfo = userInfoMapper.selectByPrimaryKey(userInfo.getOpenId());
			UserAmountRecords userAmountRecords = new UserAmountRecords();
			userAmountRecords.setOpenId(userInfo.getOpenId());
			userAmountRecords.setCurAmount(persistUserInfo.getAmount());
			userAmountRecords.setChangeAmount(userInfo.getAmount());
			userAmountRecords.setOperType((short) 1);
			userAmountRecords.setRemarks("领取红包增加余额");
			userAmountRecordsMapper.insertSelective(userAmountRecords);

			return drawFee;
		}

	}

	@Override
	public boolean hasDraw(int packetId, String openId) {
		PacketDrawRelation packetDrawRelation = packetDrawRelationMapper.selectByOpenIdAndPacketId(openId,packetId);
		return packetDrawRelation != null;
	}

	@Override
	public List<Map<String,Object>> getDrawList(PacketDrawRelation packetDrawRelation) {
		return packetDrawRelationMapper.getDrawList(packetDrawRelation);
	}

	@Override
	public List<VoiceRedPacket> findListByEntity(VoiceRedPacket voiceRedPacket) {
		return voiceRedPacketMapper.findListByEntity(voiceRedPacket);
	}

	@Override
	public void updataPayStatusAndAmount(VoiceRedPacket voiceRedPacket, UserInfo userInfo) {
		voiceRedPacketMapper.updateByPrimaryKeySelective(voiceRedPacket);
		userInfoMapper.addAmount(userInfo);

		UserInfo persistUserInfo = userInfoMapper.selectByPrimaryKey(userInfo.getOpenId());
		UserAmountRecords userAmountRecords = new UserAmountRecords();
		userAmountRecords.setOpenId(userInfo.getOpenId());
		userAmountRecords.setCurAmount(persistUserInfo.getAmount());
		userAmountRecords.setChangeAmount(userInfo.getAmount());
		userAmountRecords.setOperType((short) 2);
		userAmountRecords.setRemarks("发红包扣减余额");
		userAmountRecordsMapper.insertSelective(userAmountRecords);
	}

	@Override
	public List<VoiceRedPacket> getPublicPacketList(VoiceRedPacket voiceRedPacket) {
		return voiceRedPacketMapper.getPublicPacketList(voiceRedPacket);
	}

}
