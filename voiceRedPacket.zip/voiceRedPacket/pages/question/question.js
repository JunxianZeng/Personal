Page({
  data: {
    list: [
      // {
      //   id: '1',
      //   name: '发口令会收取服务费吗',
      //   open: false,
      //   pages: ['发口令不会收取服务费']
      // },
      // {
      //   id: '2',
      //   name: '提现会收取服务费吗',
      //   open: false,
      //   pages: ['提现会收取1%的服务费']
      // },
      // {
      //   id: '3',
      //   name: '在哪里提现',
      //   open: false,
      //   pages: ['在底部<我的>页面有提现按钮，提现最小额度为1元，每天最多提现3次。申请提现后会在1-2个工作日转账到您的微信钱包。']
      // },
      {
        id: '1',
        name: '红声小程序介绍',
        open: false,
        pages: ['红声小程序目前仅为大家节日娱乐消遣。每个用户会赠送1000元虚拟红包，大家可尽情玩耍。因为是虚拟钱币，无法提现为真实货币。']
      },
      {
        id: '2',
        name: '语音红包怎么玩？',
        open: false,
        pages: ['目前有两种玩法，语音口令和你问我答。语音口令是让对方语音说出你的口令即可领取红包。你问我答是让对方语音回答你的问题即可领取红包。']
      },
      {
        id: '3',
        name: '未领取的金额怎么处理',
        open: false,
        pages: ['未领取的金额将于24小时后退至小程序余额，可在底部<我的>页面查看。']
      }
    ]
  },
  kindToggle: function (e) {
    var id = e.currentTarget.id, list = this.data.list;
    for (var i = 0, len = list.length; i < len; ++i) {
      if (list[i].id == id) {
        list[i].open = !list[i].open
      } else {
        list[i].open = false
      }
    }
    this.setData({
      list: list
    });
  }
});
