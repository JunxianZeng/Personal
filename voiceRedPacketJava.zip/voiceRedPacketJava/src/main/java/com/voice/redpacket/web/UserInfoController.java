package com.voice.redpacket.web;

import com.voice.redpacket.constant.Constant;
import com.voice.redpacket.domain.PacketDrawRelation;
import com.voice.redpacket.domain.UserAmountRecords;
import com.voice.redpacket.domain.UserInfo;
import com.voice.redpacket.domain.VoiceRedPacket;
import com.voice.redpacket.service.IUserInfoService;
import com.voice.redpacket.service.IVoiceRedPacketService;
import com.voice.redpacket.service.IWxPayInfoService;
import com.voice.redpacket.util.JedisUtil;
import net.sf.json.JSONObject;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * Created by ZhaoYuJie on 2018/1/31.
 */
@Controller
@RequestMapping("/")
public class UserInfoController {
	private static Logger _log = LoggerFactory
			.getLogger(UserInfoController.class);
	@Resource
	private IUserInfoService userInfoService;
	@Resource
	private IVoiceRedPacketService voiceRedPacketService;
	@Resource
	private IWxPayInfoService wxPayInfoService;
	



	@RequestMapping(value = "/getUserAmount")
	@ResponseBody
	public String getUserAmount(@RequestParam String sessionId) {
		
		JSONObject resultJO = new JSONObject();
		
		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_UNLONGIN);
			resultJO.put(Constant.RET_MSG, "未登录");
			return resultJO.toString();
		}

		String openId = sessionValue.split("#")[1];

		UserInfo userInfo = userInfoService.getUserInfoByOpenId(openId);

		resultJO.put("amount",userInfo.getAmount());

		resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);

		return resultJO.toString();
	}

	@RequestMapping(value = "/getMySendAndDraw")
	@ResponseBody
	public String getMySendAndDraw(@RequestParam String sessionId) {

		JSONObject resultJO = new JSONObject();

		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_UNLONGIN);
			resultJO.put(Constant.RET_MSG, "未登录");
			return resultJO.toString();
		}

		String openId = sessionValue.split("#")[1];

		VoiceRedPacket tmp = new VoiceRedPacket();
		tmp.setOpenId(openId);
		List<VoiceRedPacket> voiceRedPacketSendList = voiceRedPacketService.findListByEntity(tmp);
		int totalSendMoney = 0;
		if(CollectionUtils.isNotEmpty(voiceRedPacketSendList)){
			for(VoiceRedPacket voiceRedPacket : voiceRedPacketSendList){
				totalSendMoney += voiceRedPacket.getFee();
			}
		}

		PacketDrawRelation relation = new PacketDrawRelation();
		relation.setOpenId(openId);
		List<Map<String, Object>> drawList = voiceRedPacketService.getDrawList(relation);
		int totalReceivedMoney = 0;
		if(CollectionUtils.isNotEmpty(drawList)){
			for(Map<String, Object> draw : drawList){
				int drawFee = Integer.valueOf(draw.get("drawFee").toString());
				totalReceivedMoney += drawFee;
			}
		}

		resultJO.put("totalSendMoney",totalSendMoney);
		resultJO.put("totalSendNum",voiceRedPacketSendList != null ? voiceRedPacketSendList.size() : 0);
		resultJO.put("voiceRedPacketSendList",voiceRedPacketSendList);

		resultJO.put("totalReceivedMoney",totalReceivedMoney);
		resultJO.put("totalReceivedNum",drawList != null ? drawList.size() : 0);
		resultJO.put("drawList",drawList);

		resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);

		return resultJO.toString();
	}

	@RequestMapping(value = "/getAmountDetail")
	@ResponseBody
	public String getAmountDetail(@RequestParam String sessionId) {

		JSONObject resultJO = new JSONObject();

		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_UNLONGIN);
			resultJO.put(Constant.RET_MSG, "未登录");
			return resultJO.toString();
		}

		String openId = sessionValue.split("#")[1];

		List<UserAmountRecords> amountRecordList= userInfoService.findUserAmountRecords(openId);

		resultJO.put("amountRecordList",amountRecordList);

		resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);

		return resultJO.toString();
	}


}
