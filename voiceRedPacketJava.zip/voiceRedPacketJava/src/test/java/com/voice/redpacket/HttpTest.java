package com.voice.redpacket;

import com.voice.redpacket.util.FileUtil;
import com.voice.redpacket.util.HttpUtil;
import net.sf.json.JSONObject;
import org.junit.Test;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;

/**
 * Created by ZhaoYuJie on 2018/1/29.
 */
public class HttpTest {
    @Test
    public void getAccessToken(){
        String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx09631bb1d745f999&secret=d260965f92ce04032d5e83aaf17fe264";
        String result = HttpUtil.sendGet(url);
        System.out.println(result);
    }
    @Test
    public void getWxCode() throws FileNotFoundException {
        String tokenurl = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx09631bb1d745f999&secret=d260965f92ce04032d5e83aaf17fe264";
        String result = HttpUtil.sendGet(tokenurl);
        JSONObject jsonObject = JSONObject.fromObject(result);
        String access_token = jsonObject.getString("access_token");

        String url ="https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token="+access_token;
        JSONObject param = new JSONObject();
        param.put("scene","packetId=4");

        InputStream instream = HttpUtil.post4Stream(url, param.toString());
        FileUtil.saveToImgByInputStream(instream,"E://QQ.png");


    }



}
