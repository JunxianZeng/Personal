package com.voice.redpacket.aop;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Map;

/**
 * Controller层的拦截器
 * @author zhaoyujie
 */
@Aspect
public class CtrlAspect {
    private static Logger _log = LoggerFactory.getLogger(CtrlAspect.class);

    @Around(value = "execution(public * com.voice.redpacket.web.*Controller.*(..))")
    public Object exceptionHandle(final ProceedingJoinPoint pjp) throws Throwable {
        Object returnVal = null;

        String classMethod = pjp.getThis().getClass().getName()+"|"+pjp.getSignature().getName();
        String inputArgs = toString(pjp.getArgs());
        
        _log.info("开始执行方法{},参数{}",classMethod,inputArgs);
        try {
            returnVal = pjp.proceed();
            if(_log.isDebugEnabled()){ //返回数据量太大，只在debug时输出
            	if(returnVal instanceof Object[] || returnVal instanceof Collection){
                	_log.debug("方法{},参数{}执行结束,返回{}",classMethod,inputArgs,JSONArray.fromObject(returnVal).toString());
                }else if(returnVal instanceof Map){
                	_log.debug("方法{},参数{}执行结束,返回{}",classMethod,inputArgs,JSONObject.fromObject(returnVal).toString());
                }else{
                	_log.debug("方法{},参数{}执行结束,返回{}",classMethod,inputArgs,returnVal);
                }
            }
        } catch (Throwable e) {
            _log.error("系统错误",e);
            e.printStackTrace();
            _log.info("方法{},参数{}执行结束,返回{}",classMethod,inputArgs,returnVal);
            throw e;
        }
        _log.info("方法{},参数{}执行结束,返回{}",classMethod,inputArgs,returnVal);

        return returnVal;
    }


    private String toString(Object[] args) {
        StringBuilder sb = new StringBuilder();
        for (Object arg : args) {
            if(arg instanceof HttpServletResponse){ //忽略HttpServletResponse
                continue;
            }
            if(arg instanceof HttpServletRequest){ //记录request中的参数
                HttpServletRequest request = (HttpServletRequest) arg;
                Enumeration<?> it = request.getParameterNames();
                sb.append("HttpServletRequest[");
                while(it.hasMoreElements()){
                    String paramName = it.nextElement().toString();
                    sb.append(paramName+"="+request.getParameter(paramName)).append(",");
                }
                sb.append("]");
                continue;
            }
            sb.append(arg).append(",");
        }
        return sb.toString();
    }

}
