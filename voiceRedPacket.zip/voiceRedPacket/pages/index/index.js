//index.js
//获取应用实例
const app = getApp()
var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置

Page({
  data: {
    tabs: ["语音口令", "你问我答"],
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,

    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    placeholder: '恭喜发财大吉大利',
    needPay: '0.00',
    array: ['无限制', '1秒', '2秒', '3秒', '4秒', '5秒', '6秒', '7秒', '8秒', '9秒','10秒'],
    index: 0,
    voiceBtnText:'长按录入您的语音问题',
    j: 1,//帧动画初始图片
    isSpeaking: false,//是否正在说话
    tempFilePath: '',
    isRecorded:false,
    amount:0.00,
    initValue:''
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          sliderLeft: (res.windowWidth / that.data.tabs.length - sliderWidth) / 2,
          sliderOffset: res.windowWidth / that.data.tabs.length * that.data.activeIndex
        });
      }
    });

    wx.showShareMenu({
      withShareTicket: true
    })

    if (app.globalData.userInfo) {
      console.log("globalData有用户信息")
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      console.log("异步请求用户信息")
      app.userInfoReadyCallback = res => {
        app.globalData.userInfo = res.userInfo
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          console.log("异步请求用户信息2")
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
    console.log("========" + app.globalData.userInfo)
    
  },
  onShow:function(){
    var that = this;
    that.setData({
      initValue: ''
    })
    that.resetVoice();
    var sessionId = wx.getStorageSync("sessionId");
    if (sessionId != '' && sessionId != null){
      wx.request({
        url: app.globalData.baseUrl + 'getUserAmount.htm?sessionId=' + sessionId,
        success: function (res) {
          var retCode = res.data.retCode;
          var retMsg = res.data.retMsg;
          if (retCode == 0) { //成功
            that.setData({
              amount: (res.data.amount / 100).toFixed(2)
            })
          }
        }
      })
    }
    app.sessionReadyCallback = sessionId => {
      wx.request({
        url: app.globalData.baseUrl + 'getUserAmount.htm?sessionId=' + sessionId,
        success: function (res) {
          var retCode = res.data.retCode;
          var retMsg = res.data.retMsg;
          if (retCode == 0) { //成功
            that.setData({
              amount: (res.data.amount / 100).toFixed(2)
            })
          }
        }
      })
    }
  },
  tabClick: function (e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id
    });
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  bindNeedPay: function (e) {
    // this.setData({
    //   needPay: e.detail.value ? (e.detail.value / 100).toFixed(2) :'0.00'
    // })
  },
  createVoice: function(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    var that = this;
    //检查输入项是否合法
    var text = e.detail.value.text.trim();
    var fee = e.detail.value.fee;
    var num = e.detail.value.num;
    var limitTime = e.detail.value.limitTime;
    var isPublic = e.detail.value.isPublic;
    var sessionId = wx.getStorageSync("sessionId");
    var shareScope = 0;
    
    if(text==""){
      wx.showModal({
        content: '口令不能为空',
        showCancel: false
      });
      return;
    }
    if (fee == "") {
      wx.showModal({
        content: '赏金不能为空',
        showCancel: false
      });
      return;
    }
    if (num == "") {
      wx.showModal({
        content: '数量不能为空',
        showCancel: false
      });
      return;
    }

    if (parseFloat(fee) / parseInt(num) < 0.01) { //每人至少领取1分钱
      wx.showModal({
        content: '每人至少领取1分钱',
        showCancel: false
      });
      return;
    }

    if (sessionId == "" || sessionId == null) {
      app.userLogin(that.createVoice, e);
      return;
    }

    if (isPublic == true){ //分享到广场
      shareScope = 1;
    }

    var voiceParam = { "topele": that, "text": text, "fee": fee, "num": num, "limitTime": limitTime, "shareScope": shareScope, "type": 1 };
    //下单，支付，待开发
    if(parseFloat(fee)<=parseFloat(that.data.amount)){
      that.generateVoice(voiceParam);
    }else{
      that.generateOrder(voiceParam);
    }

  },
  generateVoice: function (voiceParam) {
    wx.showLoading({
      title: '生成语音口令中...',
    })
    var that = this;
    //生成语音，返回页面id
    wx.request({
      url: app.globalData.baseUrl + 'createVoice.htm',
      data: {
        sessionId: wx.getStorageSync("sessionId"),
        text: voiceParam.text,
        fee: voiceParam.fee * 100,
        num: voiceParam.num,
        limitTime: voiceParam.limitTime,
        shareScope: voiceParam.shareScope,
        'type':voiceParam.type
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: "POST",
      success: function (res) {
        console.log(res.data)
        var packetId = res.data.packetId;
        if (res.data.retCode == -1) { //session已失效，重新登录并回调createVoice
          wx.hideLoading();
          app.userLogin(voiceParam.topele.createVoice, e);
          return;
        } else if (res.data.retCode == 0) { //成功
          if (voiceParam.type == 1) { //语音口令
            wx.hideLoading();
            wx.navigateTo({
              url: '../voice/voice?packetId=' + packetId,
            })
          } else if (voiceParam.type == 2) { //你问我答，需要上传语音问题
            wx.uploadFile({
              url: app.globalData.baseUrl + 'uploadQuestion.htm',
              filePath: that.data.tempFilePath,
              name: 'file',
              formData: {
                packetId: packetId,
                sessionId: wx.getStorageSync("sessionId")
              },
              header: { 'content-type': 'multipart/form-data' },
              success: function (res) {
                wx.hideLoading();

                var retCode;
                var retMsg;

                if (typeof res.data == 'string') {
                  res.data = JSON.parse(res.data);
                }
                retCode = res.data.retCode;
                retMsg = res.data.retMsg;

                if (retCode == 0) { //上传语音问题成功
                  wx.navigateTo({
                    url: '../answer/answer?packetId=' + packetId,
                  })
                } else {
                  wx.showModal({
                    content: retMsg,
                    showCancel: false
                  });
                  return;
                }
              },
              fail: function (res) {
                console.log("[Console log]:uploadQuestion failed:" + res.errMsg);
                wx.hideLoading();
                wx.showModal({
                  content: '生成语音口令失败！',
                  showCancel: false,
                  confirmText: '确定',
                  confirmColor: '#09BB07',
                })
              }
            })
          }
          
        }
      }
    })
  },
  /**生成商户订单 */
  generateOrder: function (voiceParam) {
    wx.showLoading({
      title: '生成语音口令中...',
    })
    var that = this
    //统一支付   
    wx.request({
      url: app.globalData.baseUrl + 'order/unifiedorder.htm',
      data: {
        sessionId: wx.getStorageSync("sessionId"),
        text: voiceParam.text,
        fee: voiceParam.fee * 100,
        num: voiceParam.num,
        limitTime: voiceParam.limitTime,
        shareScope: voiceParam.shareScope,
        'type': voiceParam.type
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: "POST",
      success: function (res) {
        console.log(res)
        var retCode = res.data.retCode;
        var retMsg = res.data.retMsg;
        
        if(retCode != 0){
          wx.hideLoading();
          wx.showModal({
            content: retMsg,
            showCancel: false
          });
          return;
        }
        var paymentJson = res.data.paymentJson;
        var packetId = res.data.packetId;
        //发起支付   
        var timeStamp = paymentJson.timeStamp;
        console.log("timeStamp:" + timeStamp)
        var packages = paymentJson.package;
        console.log("package:" + packages)
        var paySign = paymentJson.paySign;
        console.log("paySign:" + paySign)
        var nonceStr = paymentJson.nonceStr;
        console.log("nonceStr:" + nonceStr)
        var param = { "timeStamp": timeStamp, "package": packages, "paySign": paySign, "signType": "MD5", "nonceStr": nonceStr, "packetId": packetId, "type": voiceParam.type};

        if (voiceParam.type == 1){ //语音口令
          wx.hideLoading();
          that.pay(param);
        } else if (voiceParam.type == 2) { //你问我答，需要上传语音问题
          wx.uploadFile({
            url: app.globalData.baseUrl + 'uploadQuestion.htm',
            filePath: that.data.tempFilePath,
            name: 'file',
            formData: {
              packetId: packetId,
              sessionId: wx.getStorageSync("sessionId")
            },
            header: { 'content-type': 'multipart/form-data' },
            success: function (res) {
              wx.hideLoading();

              var retCode;
              var retMsg;

              if (typeof res.data == 'string') {
                res.data = JSON.parse(res.data);
              }
              retCode = res.data.retCode;
              retMsg = res.data.retMsg;

              if (retCode == 0) { //上传语音问题成功
                that.pay(param);
              } else {
                wx.showModal({
                  content: retMsg,
                  showCancel: false
                });
                return;
              }
            },
            fail: function (res) {
              console.log("[Console log]:uploadQuestion failed:" + res.errMsg);
              wx.hideLoading();
              wx.showModal({
                content: '生成语音口令失败！',
                showCancel: false,
                confirmText: '确定',
                confirmColor: '#09BB07',
              })
            }
          })
        }
        
      },
      fail: function (res) {
        console.log("[Console log]:unifiedorder failed:" + res.errMsg);
        wx.hideLoading();
        wx.showModal({
          content: '生成语音口令失败！',
          showCancel: false,
          confirmText: '确定',
          confirmColor: '#09BB07',
        })
      }
    })
  },
  /* 支付   */
  pay: function (param) {
    var that = this;
    console.log('支付参数：'+param)
    wx.requestPayment({
      timeStamp: param.timeStamp,
      nonceStr: param.nonceStr,
      package: param.package,
      signType: param.signType,
      paySign: param.paySign,
      success: function (res) {
        console.log('支付结果：'+res)

        if (param.type == 1) {
          wx.navigateTo({
            url: '../voice/voice?packetId=' + param.packetId,
          })
        } else if (param.type == 2) {
          wx.navigateTo({
            url: '../answer/answer?packetId=' + param.packetId,
          })
        }

      },
      fail: function (res) {
        // fail   
        console.log("支付失败")
        console.log(res)
      },
      complete: function () {
        // complete   
        console.log("pay complete")
      }
    })
  },
  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  //手指按下
  touchdown: function () {
    console.log("手指按下了...")
    if (this.data.isRecorded){
      return;
    }
    var _this = this;
    speaking.call(this);
    this.setData({
      isSpeaking: true
    })
    //开始录音
    wx.startRecord({
      success: function (res) {
        //临时路径,下次进入小程序时无法正常使用
        var tempFilePath = res.tempFilePath
        console.log("tempFilePath: " + tempFilePath)
        _this.setData({
          tempFilePath: tempFilePath,
          isRecorded: true,
          voiceBtnText:'录音完成，试听一下？'
        })

        wx.showToast({
          title: '恭喜!录音成功',
          icon: 'success',
          duration: 1000
        })
        
      },
      fail: function (res) {
        //录音失败
        // wx.showModal({
        //   title: '提示',
        //   content: '录音的姿势不对!',
        //   showCancel: false,
        //   success: function (res) {
        //     if (res.confirm) {
        //       console.log('用户点击确定')
        //       return
        //     }
        //   }
        // })
      }
    })
  },
  //手指抬起
  touchup: function () {
    console.log("手指抬起了...")
    if (this.data.isRecorded) {
      return;
    }
    this.setData({
      isSpeaking: false,
    })
    clearInterval(this.timer)
    wx.stopRecord()
  },
  //点击播放录音
  gotoPlay: function (e) {
    if (!this.data.isRecorded) {
      return;
    }
    var filePath = this.data.tempFilePath;
    //点击开始播放
    wx.showToast({
      title: '开始播放',
      icon: 'success',
      duration: 1000
    })
    wx.playVoice({
      filePath: filePath,
      success: function () {
        wx.showToast({
          title: '播放结束',
          icon: 'success',
          duration: 1000
        })
      }
    })
  },
  resetVoice:function(e) {
    console.log("重置录音按钮")
    this.setData({
      tempFilePath:'',
      isRecorded:false,
      voiceBtnText:'长按录入您的语音问题'
    })
  },
  createQuestion: function (e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    var that = this;
    //检查输入项是否合法
    var text = e.detail.value.text.trim();
    var fee = e.detail.value.fee;
    var num = e.detail.value.num;
    var limitTime = 0; //问答没有语音时长限制
    var isPublic = e.detail.value.isPublic;
    var sessionId = wx.getStorageSync("sessionId");
    var shareScope = 0;

    if (!that.data.isRecorded || that.data.tempFilePath==''){
      wx.showModal({
        content: '请先录入语音问题',
        showCancel: false
      });
      return;
    }
    if (text == "") {
      wx.showModal({
        content: '语音答案不能为空',
        showCancel: false
      });
      return;
    }
    if (fee == "") {
      wx.showModal({
        content: '赏金不能为空',
        showCancel: false
      });
      return;
    }
    if (num == "") {
      wx.showModal({
        content: '数量不能为空',
        showCancel: false
      });
      return;
    }

    if (parseFloat(fee) / parseInt(num) < 0.01){ //每人至少领取1分钱
      wx.showModal({
        content: '每人至少领取1分钱',
        showCancel: false
      });
      return;
    }

    if (sessionId == "" || sessionId == null) {
      app.userLogin(that.createQuestion, e);
      return;
    }

    if (isPublic == true) { //分享到广场
      shareScope = 1;
    }

    var voiceParam = { "topele": that, "text": text, "fee": fee, "num": num, "limitTime": limitTime, "shareScope": shareScope,"type": 2 };
    //下单，支付，待开发
    if (parseFloat(fee)<=parseFloat(that.data.amount)) {
      that.generateVoice(voiceParam);
    } else {
      that.generateOrder(voiceParam);
    }

  },
  onShareAppMessage: function (res) {
    var that = this;
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '快来领取语音红包',
      path: '/pages/index/index',
      success: function (res) {
        // 转发成功
        console.log("转发成功")
        wx.showModal({
          content: '转发成功',
          showCancel: false
        })
      },
      fail: function (res) {
        // 转发失败
        console.log("转发失败")
      }
    }
  }

})

//麦克风帧动画
function speaking() {
  var _this = this;
  //话筒帧动画
  var i = 1;
  this.timer = setInterval(function () {
    i++;
    i = i % 5;
    _this.setData({
      j: i
    })
  }, 200);
}

