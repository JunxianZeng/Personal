package com.voice.redpacket.constant;

import com.voice.redpacket.util.ConfigUtil;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
public class Constant {
    /**微信分配的小程序ID*/
    public static final String WX_XIAOCHENGXU_APPID = ConfigUtil.getValue("WX_XIAOCHENGXU_APPID");
    /**微信分配的小程序密钥*/
    public static final String WX_XIAOCHENGXU_SECRET = ConfigUtil.getValue("WX_XIAOCHENGXU_SECRET");

    /**微信支付分配的商户号*/
    public static final String WX_XIAOCHENGXU_MCH_ID = ConfigUtil.getValue("WX_XIAOCHENGXU_MCH_ID");
    /**商户平台设置的支付密钥*/
    public static final String WX_XIAOCHENGXU_MCH_KEY = ConfigUtil.getValue("WX_XIAOCHENGXU_MCH_KEY");

    /**异步接收微信支付结果通知的回调地址，通知url必须为外网可访问的url，不能携带参数*/
    public static final String WX_XIAOCHENGXU_NOTIFY_URL = ConfigUtil.getValue("WX_XIAOCHENGXU_NOTIFY_URL");
    /**微信统一下单接口*/
    public static final String WX_UNIFIED_ORDER_URL = ConfigUtil.getValue("WX_UNIFIED_ORDER_URL");
    /**获取AccessToken的url*/
    public static final String WX_XIAOCHENGXU_ACCESS_TOKEN_URL = ConfigUtil.getValue("WX_XIAOCHENGXU_ACCESS_TOKEN_URL");

    /**
     * 0：成功    <br/>-1：代表未登录 <br/>其他值：代表失败
     */
    public static final String RET_CODE = "retCode";
    public static final String RET_MSG = "retMsg";

    public static final int RET_CODE_OK = 0;
    public static final int RET_CODE_UNLONGIN = -1;

    public static final String VOICE_REDPACKET_SESSION = "voice_redpacket_session_";
    public static final String VOICE_REDPACKET_RANDOM_MONEYS = "voice_redpacket_random_moneys_";
    public static final int VOICE_REDPACKET_EXPIRYDATE = 24*60*60; //红包有效期为1天
    public static final String VOICE_REDPACKET_ACCESS_TOKEN = "voice_redpacket_access_token_";

}
