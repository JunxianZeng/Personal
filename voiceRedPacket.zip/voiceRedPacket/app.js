//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    var that = this;
    // 登录
    that.userLogin();

    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (!res.authSetting['scope.userInfo']) {
          wx.authorize({ //开发工具不执行，手机上可以
            scope: 'scope.userInfo',
            success() {
              console.log("**********scope.userInfo********")
            },
            fail() {
              wx.showModal({
                title: '温馨提示',
                content: '拒绝授权将无法正常使用小程序',
                confirmText: "允许授权",
                cancelText: "拒绝到底",
                success: function (res) {
                  console.log(res);
                  if (res.confirm) {
                    wx.openSetting({
                      //重新请求授权
                      success: (res) => {
                        that.userLogin();
                      }
                    })
                  } else {
                    console.log('用户拒绝授权scope.userInfo')
                  }
                }
              });
              
            }
          })
        }
        if (!res.authSetting['scope.record']) {
          wx.authorize({
            scope: 'scope.record',
            success() {
              console.log("*********scope.record*********")
            },
            fail() {
              wx.showModal({
                title: '温馨提示',
                content: '拒绝授权将无法正常使用录音功能',
                confirmText: "允许授权",
                cancelText: "拒绝到底",
                success: function (res) {
                  console.log(res);
                  if (res.confirm) {
                    wx.openSetting({

                    })
                  } else {
                    console.log('用户拒绝授权scope.record')
                  }
                }
              });
              
            }
          })
        }
        if (!res.authSetting['scope.writePhotosAlbum']) {
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success() {
              console.log("*********scope.writePhotosAlbum*********")
            },
            fail() {
              wx.showModal({
                title: '温馨提示',
                content: '拒绝授权将无法正常使用保存图片功能',
                confirmText: "允许授权",
                cancelText: "拒绝到底",
                success: function (res) {
                  console.log(res);
                  if (res.confirm) {
                    wx.openSetting({

                    })
                  } else {
                    console.log('用户拒绝授权scope.writePhotosAlbum')
                  }
                }
              });

            }
          })
        }
      }
    })
  },
  userLogin: function (func, arg) { //登陆后若需回调则传响应参数。func：回调函数，arg：回调函数的参数
    var that = this;
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
        if (res.code) {
          //发起网络请求
          wx.request({
            url: that.globalData.baseUrl + 'getSessionKeyByCode.htm',
            data: {
              code: res.code
            },
            success: function (res) {
              console.log(res.data)
              if (res.data) {
                var sessionId = res.data.sessionId;
                wx.setStorage({
                  key: "sessionId",
                  data: sessionId
                })

                wx.getUserInfo({
                  success: res => {
                    that.globalData.userInfo = res.userInfo;
                    // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
                    // 所以此处加入 callback 以防止这种情况
                    if (that.userInfoReadyCallback) {
                      that.userInfoReadyCallback(res)
                    }
                    // 可以将 res 发送给后台解码出 unionId
                    wx.request({
                      url: that.globalData.baseUrl + 'decodeUserInfo.htm',
                      data: {
                        encryptedData: res.encryptedData,
                        iv: res.iv,
                        sessionId: sessionId
                      },
                      header: {
                        'content-type': 'application/x-www-form-urlencoded'
                      },
                      method: "POST",
                      success: function (res) {
                        console.log(res.data)
                        if (res.data.openId =='ooJ_S5EsoPMVT25VQ7JRFN7uLF4Q'){ //我的账号登录
                          // 打开调试
                          wx.setEnableDebug({
                            enableDebug: true
                          })
                        }
                        if(typeof func == 'function'){
                          func(arg); //回调函数
                        }
                        if (that.sessionReadyCallback) {
                          that.sessionReadyCallback(sessionId)
                        }
                      }
                    })

                  },
                  fail: function(){
                    console.log("---------------------------");
                    wx.openSetting({
                      //重新请求授权
                      success: (res) => {
                        console.log("@@@@@@@@@@@@@@")
                        //重新登录，目的是强制用户授权
                        that.userLogin();
                      }
                    })
                  }
                })


              }
            }
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }
      }
    })
  },
  globalData: {
    userInfo: null,
    // baseUrl: 'http://192.168.8.126/'
    baseUrl: 'https://www.remotejob.cn/'
  }
})