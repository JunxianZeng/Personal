package com.voice.redpacket.service;

import com.voice.redpacket.domain.PacketDrawRelation;
import com.voice.redpacket.domain.UserInfo;
import com.voice.redpacket.domain.VoiceRedPacket;

import java.util.List;
import java.util.Map;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
public interface IVoiceRedPacketService {

	void createVoice(VoiceRedPacket voiceRedPacket);

	VoiceRedPacket getVoiceRedPacket(int packetId);

	/**
	 * 领取随机红包
	 * @param voiceRedPacket
	 * @param openId
	 * @param uuid
     * @param duration
	 * @return 返回领取的金额
     */
	int draw(VoiceRedPacket voiceRedPacket, String openId, String uuid, long duration);

	boolean hasDraw(int packetId, String openId);

	List<Map<String,Object>> getDrawList(PacketDrawRelation packetDrawRelation);

	List<VoiceRedPacket> findListByEntity(VoiceRedPacket voiceRedPacket);

	void updataPayStatusAndAmount(VoiceRedPacket voiceRedPacket, UserInfo userInfo);

	List<VoiceRedPacket> getPublicPacketList(VoiceRedPacket voiceRedPacket);
}
