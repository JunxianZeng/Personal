package com.voice.redpacket.web;

import com.voice.redpacket.constant.Constant;
import com.voice.redpacket.domain.PacketDrawRelation;
import com.voice.redpacket.domain.UserInfo;
import com.voice.redpacket.domain.VoiceRedPacket;
import com.voice.redpacket.domain.WxPayInfo;
import com.voice.redpacket.service.IUserInfoService;
import com.voice.redpacket.service.IVoiceRedPacketService;
import com.voice.redpacket.service.IWxPayInfoService;
import com.voice.redpacket.util.*;
import it.sauronsoftware.jave.Encoder;
import it.sauronsoftware.jave.EncoderException;
import it.sauronsoftware.jave.MultimediaInfo;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
@Controller
@RequestMapping("/")
public class RedPacketController {
	private static Logger _log = LoggerFactory.getLogger(RedPacketController.class);
	@Resource
	private IUserInfoService userInfoService;
	@Resource
	private IVoiceRedPacketService voiceRedPacketService;
	@Resource
	private IWxPayInfoService wxPayInfoService;
	
	/**语音文件根路径*/
	private static final String VOICE_DIR = ConfigUtil.getValue("voiceDir");
	/**微信小程序二维码目录*/
	private static final String WX_CODE_DIR = ConfigUtil.getValue("wxCodeDir");


	@RequestMapping("/getSessionKeyByCode")
	@ResponseBody
	public String getSessionKeyByCode(@RequestParam String code) {
		JSONObject resultJO = new JSONObject();

		String url = "https://api.weixin.qq.com/sns/jscode2session?appid="
				+ Constant.WX_XIAOCHENGXU_APPID + "&secret="
				+ Constant.WX_XIAOCHENGXU_SECRET + "&js_code=" + code
				+ "&grant_type=authorization_code";
		String result = HttpUtil.posturl(url, "");

		JSONObject jo = JSONObject.fromObject(result);

		if (!jo.has("openid") || !jo.has("session_key")) {
			_log.warn("没有获取到sessionkey，code={}，返回结果：{}", code, result);
			return null;
		}

		String sessionId = Constant.VOICE_REDPACKET_SESSION
				+ UUID.randomUUID().toString().replace("-", "");

		JedisUtil.set(sessionId,
				jo.getString("session_key") + "#" + jo.getString("openid"),
				7200);

		resultJO.put("sessionId", sessionId);

		return resultJO.toString();
	}

	/**
	 * 解密微信小程序的用户信息
	 * 
	 * @param encryptedData
	 * @param iv
	 * @param sessionId
	 * @return
	 */
	@RequestMapping(value = "/decodeUserInfo", method = RequestMethod.POST)
	@ResponseBody
	public String decodeUserInfo(@RequestParam String encryptedData,
			@RequestParam String iv, @RequestParam String sessionId,
			HttpServletRequest request, HttpServletResponse response) {
		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			return null;
		}
		String sessionKey = sessionValue.split("#")[0];

		JSONObject resultJO = new JSONObject();

		try {
			AES aes = new AES();
			byte[] resultByte = aes.decrypt(Base64.decodeBase64(encryptedData),
					Base64.decodeBase64(sessionKey), Base64.decodeBase64(iv));
			if (null != resultByte && resultByte.length > 0) {
				String wxUserInfoStr = new String(resultByte, "UTF-8");

				_log.info("解密出来的微信小程序用户信息：{}", wxUserInfoStr);

				UserInfo userInfo = createUserInfoByWxUser(wxUserInfoStr);

				resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);
				resultJO.put("openId",userInfo.getOpenId());
			}
		} catch (Exception e) {
			resultJO.put(Constant.RET_CODE, 1);
			resultJO.put(Constant.RET_MSG, "解密用户信息出错" + e.getMessage());
			e.printStackTrace();
		}
		return resultJO.toString();
	}

	/**
	 * 根据微信小程序的用户信息生成云直播的用户信息
	 * 
	 * @param wxUserInfoStr
	 * @return
	 */
	private UserInfo createUserInfoByWxUser(String wxUserInfoStr) {
		JSONObject wxUserJO = JSONObject.fromObject(wxUserInfoStr);

		String openId = wxUserJO.getString("openId");
		String unionId = wxUserJO.optString("unionId");

		UserInfo userInfo = getUserInfoByWxId(unionId, openId);

		if (userInfo == null) { // 用户不存在，创建用户信息（来源微信）
			try {
				userInfo = new UserInfo();
				userInfo.setOpenId(openId);
				userInfo.setNickName(wxUserJO.getString("nickName"));
				userInfo.setPhoto(wxUserJO.getString("avatarUrl"));
				userInfo.setGender(wxUserJO.getString("gender"));
				userInfo.setCountry(wxUserJO.getString("country"));
				userInfo.setProvince(wxUserJO.getString("province"));
				userInfo.setCity(wxUserJO.getString("city"));
				userInfo.setUnionId(unionId);
				userInfo.setCreateTime(new Date());

				userInfoService.save(userInfo);
			} catch (Exception e) {
				_log.error("createUserInfoByWxUser error", e);
				throw e;
			}
		}else{
			if(!wxUserJO.getString("avatarUrl").equals(userInfo.getPhoto()) || !wxUserJO.getString("nickName").equals(userInfo.getNickName())){
				userInfo.setPhoto(wxUserJO.getString("avatarUrl"));
				userInfo.setNickName(wxUserJO.getString("nickName"));
				userInfoService.updateSelective(userInfo);
			}
		}

		return userInfo;
	}

	private UserInfo getUserInfoByWxId(String unionId, String openId) {
		UserInfo userInfo = null;
		if (StringUtils.isNotBlank(unionId)) {
			userInfo = userInfoService.getUserInfoByUnionId(unionId);
		} else {
			userInfo = userInfoService.getUserInfoByOpenId(openId);
		}
		return userInfo;
	}

	@RequestMapping(value = "/createVoice", method = RequestMethod.POST)
	@ResponseBody
	public String createVoice(@RequestParam String sessionId,
			@RequestParam String text, @RequestParam int fee,
			@RequestParam int num,@RequestParam int limitTime,@RequestParam short shareScope,@RequestParam short type) {
		
		JSONObject resultJO = new JSONObject();
		
		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_UNLONGIN);
			resultJO.put(Constant.RET_MSG, "未登录");
			return resultJO.toString();
		}

		String openId = sessionValue.split("#")[1];

		UserInfo userInfo = userInfoService.getUserInfoByOpenId(openId);
		if(fee > userInfo.getAmount()){
			_log.info("用户{}余额不足", openId);
			resultJO.put(Constant.RET_CODE, 1);
			resultJO.put(Constant.RET_MSG, "余额不足");
			return resultJO.toString();
		}

		VoiceRedPacket voiceRedPacket = new VoiceRedPacket();
		voiceRedPacket.setOpenId(openId);
		voiceRedPacket.setText(text);
		voiceRedPacket.setFee(fee);
		voiceRedPacket.setNum(num);
		voiceRedPacket.setServerFee(fee
				* ConfigUtil.getInteger("serverFeeRate")/100);
		voiceRedPacket.setCreateTime(new Date());
		if(limitTime > 0){
			voiceRedPacket.setLimitTime(limitTime);
		}
		voiceRedPacket.setType(type);
		voiceRedPacket.setPayType((short) 0); //余额支付
		if(type==1){
			voiceRedPacket.setPayStatus((short) 1); //余额支付直接扣减余额，所以支付状态设为已支付
		}else{
			voiceRedPacket.setPayStatus((short) 0);
		}
		voiceRedPacket.setShareScope(shareScope);

		try {
			voiceRedPacketService.createVoice(voiceRedPacket);

			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);
			resultJO.put("packetId", voiceRedPacket.getId());
		} catch (Exception e) {
			resultJO.put(Constant.RET_CODE, 1);
			resultJO.put(Constant.RET_MSG, "生成语音口令出错" + e.getMessage());
			e.printStackTrace();
		}
		return resultJO.toString();
	}



	@RequestMapping("/getVoiceRedPacket")
	@ResponseBody
	public String getVoiceRedPacket(@RequestParam int packetId) {
		JSONObject resultJO = new JSONObject();

		VoiceRedPacket voiceRedPacket = voiceRedPacketService.getVoiceRedPacket(packetId);
		UserInfo providerUserInfo = userInfoService.getUserInfoByOpenId(voiceRedPacket.getOpenId());
		PacketDrawRelation tmp = new PacketDrawRelation();
		tmp.setPacketId(packetId);
		List<Map<String,Object>> drawList = voiceRedPacketService.getDrawList(tmp);

		resultJO.put("voiceRedPacket", voiceRedPacket);
		resultJO.put("providerUserInfo", providerUserInfo);
		resultJO.put("drawList", drawList);


		return resultJO.toString();
	}
	
	@RequestMapping(value = "/uploadVoice", method = RequestMethod.POST)
	@ResponseBody
	public String uploadVoice(@RequestParam String sessionId,@RequestParam int packetId,@RequestParam MultipartFile file) {
		
		JSONObject resultJO = new JSONObject();
		
		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_UNLONGIN);
			resultJO.put(Constant.RET_MSG, "未登录");
			return resultJO.toString();
		}

		VoiceRedPacket voiceRedPacket = voiceRedPacketService.getVoiceRedPacket(packetId);

		if(voiceRedPacket.getPayStatus() != 1){
			_log.info("当前语音红包尚未支付，不能领取，packetId={}", packetId);
			resultJO.put(Constant.RET_CODE, 1);
			resultJO.put(Constant.RET_MSG, "当前语音红包尚未支付，不能领取");
			return resultJO.toString();
		}

		String openId = sessionValue.split("#")[1];

		try {
			String parentPath = VOICE_DIR+File.separator+packetId+File.separator+openId;
			new File(parentPath).mkdirs();

			String fileName = file.getOriginalFilename();
			String suffix = fileName.substring(fileName.lastIndexOf("."));
			String uuid = UUID.randomUUID().toString().replace("-","");
			fileName = uuid + suffix;

			File destFile = new File(parentPath +File.separator+ fileName);
			file.transferTo(destFile);

			//解析录音文件成文字内容
			String silkPath = destFile.getAbsolutePath();
			String content = VoiceUtil.convertSilkToText(silkPath);

			String originalText = VoiceUtil.delRedundantCharacters(voiceRedPacket.getText()); //过滤掉字符串中除了中英文字符数字之外的字符
			String answerText = VoiceUtil.delRedundantCharacters(content);

			originalText = HanyuPinyinHelper.toHanyuPinyin(originalText); //将中文转为汉语拼音
			answerText = HanyuPinyinHelper.toHanyuPinyin(answerText);

			if(originalText.equalsIgnoreCase(answerText)){ //如果匹配上了
				if(voiceRedPacketService.hasDraw(packetId,openId)){
					resultJO.put(Constant.RET_CODE, 2);
					resultJO.put(Constant.RET_MSG, "您已领取过该红包！");
				}else{
					if(voiceRedPacket.getDrawNum() >= voiceRedPacket.getNum()){
						resultJO.put(Constant.RET_CODE, 3);
						resultJO.put(Constant.RET_MSG, "该红包已被领完！");
					}else if(voiceRedPacket.getCreateTime().getTime()+Constant.VOICE_REDPACKET_EXPIRYDATE*1000 < System.currentTimeMillis()){
						resultJO.put(Constant.RET_CODE, 4);
						resultJO.put(Constant.RET_MSG, "该红包已过期！");
					}else{
						String wavPath = silkPath.substring(0,silkPath.lastIndexOf("."))+".wav";
						long duration = getDuration(wavPath);
						if(voiceRedPacket.getLimitTime() != null && voiceRedPacket.getLimitTime() != 0 && duration > voiceRedPacket.getLimitTime()){
							resultJO.put(Constant.RET_CODE, 5);
							resultJO.put(Constant.RET_MSG, "当前红包要求"+voiceRedPacket.getLimitTime()+"秒内说完！");
						}else{
							int drawFee = voiceRedPacketService.draw(voiceRedPacket, openId, uuid,duration);
							if(drawFee <= 0){
								resultJO.put(Constant.RET_CODE, 6);
								resultJO.put(Constant.RET_MSG, "领取红包失败！");
							}
						}

					}

				}
			}else{
				resultJO.put(Constant.RET_CODE, 5);
				resultJO.put(Constant.RET_MSG, "没说对，再试一次！");
			}

			if(resultJO.has(Constant.RET_CODE) && resultJO.getInt(Constant.RET_CODE) != Constant.RET_CODE_OK){
				deleteUnUseFiles(destFile);
				return resultJO.toString();
			}

			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);
			resultJO.put(Constant.RET_MSG, "红包领取成功！");
			
		} catch (Exception e) {
			_log.info("上传语音出错" + e.getMessage());
			resultJO.put(Constant.RET_CODE, 1);
			resultJO.put(Constant.RET_MSG, "没说对，再试一次！");
			e.printStackTrace();
		}
		return resultJO.toString();
	}

	/**
	 * 获取音频文件时长
	 * @param filePath 文件路径
	 * @return
     */
	private long getDuration(String filePath) {
		long duration = 0;//音频长度，秒
		File source = new File(filePath);
		Encoder encoder = new Encoder();
		MultimediaInfo m = null;
		try {
			m = encoder.getInfo(source);
		} catch (EncoderException e) {
			e.printStackTrace();
		}
		long ls = m.getDuration();
		duration = ls/1000;
		return duration;
	}

	/**
	 * 删除不用的文件
	 * @param destFile
     */
	private void deleteUnUseFiles(File destFile) {
		new File(destFile.getParent(),destFile.getName().replace(".silk",".pcm")).delete();
		new File(destFile.getParent(),destFile.getName().replace(".silk",".wav")).delete();
		destFile.delete();
	}

	@RequestMapping(value = "/getAccessToken")
	@ResponseBody
	public String getAccessToken(){
		return WxUtil.getAccessToken();
	}

	@RequestMapping(value = "/getWxCodeUrl")
	@ResponseBody
	public String getWxCodeUrl(@RequestParam int packetId){
		JSONObject resultJO = new JSONObject();

		String accessToken = WxUtil.getAccessToken();
		String url ="https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token="+accessToken;
		JSONObject param = new JSONObject();
		param.put("scene","packetId="+packetId);

		InputStream instream = HttpUtil.post4Stream(url, param.toString());
		try {
			String parentPath = WX_CODE_DIR;
			new File(parentPath).mkdirs();

			String imgPath = parentPath+File.separator+packetId+".png";

			int result = FileUtil.saveToImgByInputStream(instream, imgPath);

			if(result == 1){
				resultJO.put(Constant.RET_CODE,Constant.RET_CODE_OK);
			}else{
				resultJO.put(Constant.RET_CODE,1);
				resultJO.put(Constant.RET_MSG,"获取小程序码失败");
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return resultJO.toString();
	}

	@RequestMapping(value = "/uploadQuestion", method = RequestMethod.POST)
	@ResponseBody
	public String uploadQuestion(@RequestParam String sessionId,@RequestParam int packetId,@RequestParam MultipartFile file) {

		JSONObject resultJO = new JSONObject();

		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_UNLONGIN);
			resultJO.put(Constant.RET_MSG, "未登录");
			return resultJO.toString();
		}

		String openId = sessionValue.split("#")[1];

		try {
			String parentPath = VOICE_DIR+File.separator+packetId;
			new File(parentPath).mkdirs();

			String fileName = file.getOriginalFilename();
			String suffix = fileName.substring(fileName.lastIndexOf("."));
			fileName = openId + suffix;

			File destFile = new File(parentPath +File.separator+ fileName);
			file.transferTo(destFile);

			//解析录音文件成文字内容，这里只为了生成wav文件，并不关心解析内容
			VoiceUtil.convertSilkToText(destFile.getAbsolutePath());

			VoiceRedPacket voiceRedPacket = voiceRedPacketService.getVoiceRedPacket(packetId);
			if(voiceRedPacket.getPayType()==0 && voiceRedPacket.getType()==2){ //余额支付且为你问我答类型
				voiceRedPacket.setPayStatus((short) 1);
				UserInfo userInfo = new UserInfo();
				userInfo.setOpenId(voiceRedPacket.getOpenId());
				userInfo.setAmount(-voiceRedPacket.getFee());
				voiceRedPacketService.updataPayStatusAndAmount(voiceRedPacket,userInfo);
			}

			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);
			resultJO.put(Constant.RET_MSG, "上传语音问题成功！");

		} catch (Exception e) {
			resultJO.put(Constant.RET_CODE, 1);
			resultJO.put(Constant.RET_MSG, "上传语音问题出错" + e.getMessage());
			e.printStackTrace();

			//将订单设置为下单失败
			WxPayInfo wxPayInfo = wxPayInfoService.findByPacketId(packetId);
			if(wxPayInfo != null){
				wxPayInfo.setStatus(2);
				wxPayInfoService.update(wxPayInfo);
			}

		}
		return resultJO.toString();
	}

	@RequestMapping(value = "/getPublicPacketList")
	@ResponseBody
	public String getPublicPacketList(@RequestParam String sortType){
		JSONObject resultJO = new JSONObject();

		VoiceRedPacket voiceRedPacket = new VoiceRedPacket();
		voiceRedPacket.setShareScope((short) 1);
		voiceRedPacket.setSortType(sortType);
		voiceRedPacket.setLimitNum(100);
		List<VoiceRedPacket> voiceRedPacketList = voiceRedPacketService.getPublicPacketList(voiceRedPacket);

		resultJO.put("voiceRedPacketList",voiceRedPacketList);

		return resultJO.toString();
	}

}
