//获取应用实例  
var app = getApp()
const util = require('../../utils/util.js')

Page({
  data: {
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换  
    currentTab: 0,
    userInfo: null,
    totalSendMoney: 0,
    totalSendNum: 0,
    voiceRedPacketSendList: [],
    totalReceivedMoney: 0,
    totalReceivedNum: 0,
    drawList: []

  },
  onLoad: function () {
    var that = this;

    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }

    });
    this.setData({
      userInfo: app.globalData.userInfo
    })

    wx.request({
      url: app.globalData.baseUrl + 'getMySendAndDraw.htm?sessionId=' + wx.getStorageSync("sessionId"),
      success: function (res) {
        var retCode = res.data.retCode;
        var retMsg = res.data.retMsg;
        if (retCode == 0) { //成功
          for (var i = 0; i < res.data.voiceRedPacketSendList.length;i++){
            res.data.voiceRedPacketSendList[i].createTime = util.formatSimpleTime(new Date(res.data.voiceRedPacketSendList[i].createTime.time));
            res.data.voiceRedPacketSendList[i].fee = (res.data.voiceRedPacketSendList[i].fee / 100).toFixed(2);
            if (res.data.voiceRedPacketSendList[i].type==1){
              res.data.voiceRedPacketSendList[i].label = '口令：';
            } else if (res.data.voiceRedPacketSendList[i].type == 2) {
              res.data.voiceRedPacketSendList[i].label = '答案：';
            }
          }
          for (var i = 0; i < res.data.drawList.length; i++) {
            res.data.drawList[i].drawTime = util.formatSimpleTime(new Date(res.data.drawList[i].drawTime.time));
            res.data.drawList[i].drawFee = (res.data.drawList[i].drawFee / 100).toFixed(2);
          }

          that.setData({
            totalSendMoney: (res.data.totalSendMoney / 100).toFixed(2),
            totalSendNum: res.data.totalSendNum,
            voiceRedPacketSendList: res.data.voiceRedPacketSendList,
            totalReceivedMoney: (res.data.totalReceivedMoney / 100).toFixed(2),
            totalReceivedNum: res.data.totalReceivedNum,
            drawList: res.data.drawList
          })
        } else {
          wx.showModal({
            content: retMsg,
            showCancel: false
          });
          return;
        }
      }
    })

  },
  /** 
     * 滑动切换tab 
     */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  toPacketPage: function(e){
    var packetId = e.currentTarget.dataset.packetid;
    var packetType = e.currentTarget.dataset.packettype;
    if (packetType==1){ //语音口令
      wx.navigateTo({
        url: '../voice/voice?packetId=' + packetId
      })
    } else if (packetType == 2){ //你问我答
      wx.navigateTo({
        url: '../answer/answer?packetId=' + packetId
      })
    }
    
  }

})