package com.voice.redpacket;

import it.sauronsoftware.jave.Encoder;
import it.sauronsoftware.jave.EncoderException;
import it.sauronsoftware.jave.MultimediaInfo;
import org.junit.Test;

import java.io.File;

/**
 * Created by ZhaoYuJie on 2018/2/7.
 */
public class AudioTest {
    private long getDuration(String filePath) {
        long duration = 0;//音频长度，秒
        File source = new File(filePath);
        Encoder encoder = new Encoder();
        MultimediaInfo m = null;
        try {
            m = encoder.getInfo(source);
        } catch (EncoderException e) {
            e.printStackTrace();
        }
        long ls = m.getDuration();
        duration = ls/1000;
        return duration;
    }
    @Test
    public void getDurationTest(){
        String filePath = "D:\\upload\\voiceDir\\4\\oHosW0Yzg79GVpkMVl18yvZtvDzA\\dc8f4c25c1f348cf813133ef5d42e777.wav";
        System.out.println(getDuration(filePath));
    }
}
