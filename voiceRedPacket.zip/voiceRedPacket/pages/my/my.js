const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    amount:0.00
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      userInfo: app.globalData.userInfo
    })
    var that = this;
    wx.request({
      url: app.globalData.baseUrl + 'getUserAmount.htm?sessionId=' + wx.getStorageSync("sessionId"),
      success: function (res) {
        var retCode = res.data.retCode;
        var retMsg = res.data.retMsg;
        if (retCode == 0) { //成功
          that.setData({
            amount: (res.data.amount / 100).toFixed(2)
          })
        } else {
          wx.showModal({
            content: retMsg,
            showCancel: false
          });
          return;
        }
      }
    })
  },
  toDetail: function(){
    console.log("查看明细")
    wx.navigateTo({
      url: '../amount/detail',
    })
  }

  
})