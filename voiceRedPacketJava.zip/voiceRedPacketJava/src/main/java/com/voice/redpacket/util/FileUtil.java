package com.voice.redpacket.util;

import java.io.*;

/**
 * Created by ZhaoYuJie on 2018/1/29.
 */
public class FileUtil {
    /* @param instreams 二进制流
    * @param imgPath 图片的完整路径
    * @return
    *      1：保存正常
    *      0：保存失败
    */
    public static int saveToImgByInputStream(InputStream instreams, String imgPath) throws FileNotFoundException {

        int stateInt = 1;
        File file=new File(imgPath);//可以是任何图片格式.jpg,.png等
        FileOutputStream fos=new FileOutputStream(file);
        if(instreams != null){
            try {

                byte[] b = new byte[1024];
                int nRead = 0;
                while ((nRead = instreams.read(b)) != -1) {
                    fos.write(b, 0, nRead);
                }

            } catch (Exception e) {
                stateInt = 0;
                e.printStackTrace();
            } finally {

                try {
                    fos.flush();
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return stateInt;
    }
}
