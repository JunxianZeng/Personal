CREATE DATABASE redpacket;

CREATE TABLE `user_info` (
  `openId` varchar(32) NOT NULL COMMENT '用户ID，直接使用微信的openId',
  `nickName` varchar(64) NOT NULL COMMENT '用户昵称',
  `photo` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `gender` varchar(2) DEFAULT NULL COMMENT '性别 0:未知，1:男，2:女',
  `city` varchar(32) DEFAULT NULL,
  `province` varchar(32) DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL,
  `unionId` varchar(32) DEFAULT NULL COMMENT '微信的unionId标识',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '余额（分）',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `updatetime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`openId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户信息表';

CREATE TABLE `voice_red_packet` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `openId` varchar(32) NOT NULL COMMENT '用户ID，直接使用微信的openId',
  `text` varchar(255) NOT NULL COMMENT '语音口令',
  `fee` int(11) NOT NULL DEFAULT '0' COMMENT '红包总金额（分）',
  `num` int(11) NOT NULL DEFAULT '0' COMMENT '份数，即分成多少份',
  `drawNum` int(11) NOT NULL DEFAULT '0' COMMENT '领取数量',
  `serverFee` int(11) NOT NULL DEFAULT '0' COMMENT '服务费（分）',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `payId` bigint(20) DEFAULT NULL COMMENT '订单ID，即wx_pay_info表的主键',
  `limitTime` int(11) DEFAULT NULL COMMENT '语音时长限制（即规定时间内必须说完，单位秒）',
  `type` smallint(6) NOT NULL DEFAULT '1' COMMENT '红包类型：1语音口令 2你问我答',
  `payType` smallint(6) DEFAULT '0' COMMENT '支付类型：0余额支付；1微信支付；',
  `payStatus` smallint(6) DEFAULT '0' COMMENT '支付状态：0未支付；1已支付；2已退还余额',
  `shareScope` smallint(6) DEFAULT '0' COMMENT '分享范围：0分享链接；1红包广场；',
  PRIMARY KEY (`id`),
  KEY `index_payStatus` (`payStatus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='语音红包表';

CREATE TABLE `packet_draw_relation` (
  `id` varchar(32) NOT NULL COMMENT '主键',
  `openId` varchar(32) NOT NULL COMMENT '用户ID，直接使用微信的openId',
  `packetId` int(11) NOT NULL COMMENT '红包ID，voice_red_packet表的主键',
  `drawFee` int(11) NOT NULL COMMENT '领取金额',
  `drawTime` datetime DEFAULT NULL COMMENT '领取时间',
  `duration` bigint(20) NOT NULL DEFAULT '0' COMMENT '音频时长（秒）',
  PRIMARY KEY (`id`),
  KEY `index_openId` (`openId`),
  KEY `index_packetId` (`packetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='红包领取关系表';

CREATE TABLE `wx_pay_info` (
  `payId` bigint(20) NOT NULL AUTO_INCREMENT,
  `appId` varchar(32) DEFAULT NULL COMMENT 'APPID',
  `mchId` varchar(32) DEFAULT NULL COMMENT '商户号',
  `subAppid` varchar(32) DEFAULT NULL COMMENT '微信分配的子商户公众账号ID',
  `subMchId` varchar(32) DEFAULT NULL COMMENT '微信支付分配的子商户号',
  `openId` varchar(255) DEFAULT NULL COMMENT '用户标识',
  `body` varchar(128) DEFAULT NULL COMMENT '商品描述',
  `detail` varchar(8192) DEFAULT NULL COMMENT '商品详情',
  `attach` varchar(127) DEFAULT NULL COMMENT '附加数据',
  `createtime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `prepayId` varchar(255) DEFAULT NULL COMMENT '预付款ID',
  `spBillCreateIP` varchar(32) DEFAULT NULL COMMENT '终端IP',
  `notifyUrl` varchar(2000) DEFAULT NULL COMMENT '回调地址',
  `callbackTime` datetime NULL DEFAULT NULL COMMENT '回调时间',
  `status` int(11) DEFAULT NULL COMMENT '0请求支付 1下单成功 2下单失败 3支付成功 4支付失败',
  `isSubscribe` varchar(1) DEFAULT NULL COMMENT '用户是否关注子公众账号，Y-关注，N-未关注，仅在公众账号类型支付有效',
  `bankType` varchar(16) DEFAULT NULL COMMENT '付款银行 CMC',
  `timeExpire` timestamp NULL DEFAULT NULL COMMENT '有效期结束时间',
  `goodsTag` varchar(32) DEFAULT NULL COMMENT '商品标记 WXG 商品标记',
  `tradeType` varchar(32) DEFAULT NULL COMMENT '交易类型 取值如下：JSAPI，NATIVE，APP',
  `limitPay` varchar(32) DEFAULT NULL COMMENT '指定支付方式',
  `refundState` int(11) DEFAULT NULL COMMENT '0正常，1申请退款，2同意 ，3拒绝，4退款成功',
  `outTradeNo` varchar(32) DEFAULT NULL COMMENT '商户订单号',
  `totalFee` int(11) DEFAULT NULL COMMENT '总金额',
  `returnCode` varchar(32) DEFAULT NULL COMMENT '下单请求的返回码',
  `returnMsg` varchar(128) DEFAULT NULL COMMENT '下单请求的返回消息',
  `errCodeDes` varchar(128) DEFAULT NULL COMMENT '错误码描述',
  `errCode` varchar(32) DEFAULT NULL COMMENT '错误码',
  `deviceInfo` varchar(32) DEFAULT NULL COMMENT '微信支付分配的终端设备号',
  `transactionId` varchar(32) DEFAULT NULL COMMENT '微信支付订单号',
  PRIMARY KEY (`payId`),
  UNIQUE KEY `index_outTradeNo` (`outTradeNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单支付表';

CREATE TABLE `user_amount_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `openId` varchar(32) NOT NULL COMMENT '用户ID，直接使用微信的openId',
  `curAmount` int(11) DEFAULT NULL COMMENT '当前余额',
  `changeAmount` int(11) DEFAULT NULL COMMENT '本次变化金额，负数表示扣减，正数表示增加',
  `operType` smallint(6) DEFAULT NULL COMMENT '操作类型：1领取红包；2发红包；3红包余额退还；',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  `createTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户余额变更记录表';


