package com.voice.redpacket.service;

import com.voice.redpacket.domain.WxPayInfo;

/**
 * Created by ZhaoYuJie on 2018/1/24.
 */
public interface IWxPayInfoService {

    void save(WxPayInfo wxPayInfo);

    int update(WxPayInfo wxPayInfo);

    WxPayInfo findByPayId(Long payId);

    boolean hasPaid(int packetId);

    WxPayInfo findByTradeNo(String outTradeNo);

    WxPayInfo findByPacketId(Integer packetId);

    void updateWhenPaySuccess(WxPayInfo wxPayInfo);
}
