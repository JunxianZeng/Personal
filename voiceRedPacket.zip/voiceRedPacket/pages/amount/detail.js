const app = getApp()
const util = require('../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    amountRecordList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    wx.request({
      url: app.globalData.baseUrl + 'getAmountDetail.htm?sessionId=' + wx.getStorageSync("sessionId"),
      success: function (res) {
        var retCode = res.data.retCode;
        var retMsg = res.data.retMsg;
        
        if (retCode == 0) { //成功
          var amountRecordList = res.data.amountRecordList;

          for (var i = 0; i < amountRecordList.length;i++){
            amountRecordList[i].createTime = util.formatSimpleTime(new Date(amountRecordList[i].createTime.time));
            amountRecordList[i].changeAmount = (amountRecordList[i].changeAmount / 100).toFixed(2);
            amountRecordList[i].curAmount = (amountRecordList[i].curAmount / 100).toFixed(2);
          }
          that.setData({
            amountRecordList: amountRecordList
          })
        } else {
          wx.showModal({
            content: retMsg,
            showCancel: false
          });
          return;
        }
      }
    })
  },


})