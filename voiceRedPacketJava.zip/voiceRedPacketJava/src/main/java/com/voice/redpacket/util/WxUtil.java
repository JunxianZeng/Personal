package com.voice.redpacket.util;

import com.voice.redpacket.constant.Constant;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;

import java.text.MessageFormat;

/**
 * Created by ZhaoYuJie on 2018/1/29.
 */
public class WxUtil {
    public static String getAccessToken(){
        String access_token = JedisUtil.get(Constant.VOICE_REDPACKET_ACCESS_TOKEN);

        if(StringUtils.isBlank(access_token)){
            String url = Constant.WX_XIAOCHENGXU_ACCESS_TOKEN_URL;
            Object[] params = { Constant.WX_XIAOCHENGXU_APPID, Constant.WX_XIAOCHENGXU_SECRET };
            // 从配置文件中读取模板字符串替换
            url = MessageFormat.format(url, params);
            String result = HttpUtil.sendGet(url);
            JSONObject jsonObject = JSONObject.fromObject(result);
            access_token = jsonObject.getString("access_token");
            int expires_in = jsonObject.getInt("expires_in");

            JedisUtil.set(Constant.VOICE_REDPACKET_ACCESS_TOKEN,access_token,expires_in-10); //少10秒，以免时差
        }

        return access_token;
    }
}
