package com.voice.redpacket.timer;

import com.voice.redpacket.dao.UserAmountRecordsMapper;
import com.voice.redpacket.dao.UserInfoMapper;
import com.voice.redpacket.dao.VoiceRedPacketMapper;
import com.voice.redpacket.domain.UserAmountRecords;
import com.voice.redpacket.domain.UserInfo;
import com.voice.redpacket.domain.VoiceRedPacket;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZhaoYuJie on 2018/2/11.
 */
@Component
public class RedPacketRefundTimer {
    private static Logger _log = LoggerFactory.getLogger(RedPacketRefundTimer.class);

    @Resource
    private VoiceRedPacketMapper voiceRedPacketMapper;
    @Resource
    private UserInfoMapper userInfoMapper;
    @Resource
    private UserAmountRecordsMapper userAmountRecordsMapper;


    public void task(){
        _log.info("退还未领取的红包余额。。。");
        List<VoiceRedPacket> waitingRefundList = voiceRedPacketMapper.findWaitingRefundList();
        if(CollectionUtils.isEmpty(waitingRefundList)){
            return;
        }

        List<Integer> packetIdList = new ArrayList<>();

        for(VoiceRedPacket voiceRedPacket : waitingRefundList){
            voiceRedPacket.setPayStatus((short) 2); //已退还余额
            voiceRedPacketMapper.updateByPrimaryKeySelective(voiceRedPacket);

            int refundAmount = voiceRedPacket.getFee() - voiceRedPacket.getDrawTotalFee();
            //退款
            UserInfo userInfo = new UserInfo();
            userInfo.setOpenId(voiceRedPacket.getOpenId());
            userInfo.setAmount(refundAmount);
            userInfoMapper.addAmount(userInfo);

            UserInfo persistUserInfo = userInfoMapper.selectByPrimaryKey(userInfo.getOpenId());
            UserAmountRecords userAmountRecords = new UserAmountRecords();
            userAmountRecords.setOpenId(userInfo.getOpenId());
            userAmountRecords.setCurAmount(persistUserInfo.getAmount());
            userAmountRecords.setChangeAmount(userInfo.getAmount());
            userAmountRecords.setOperType((short) 3);
            userAmountRecords.setRemarks("退还未领取的红包余额");
            userAmountRecordsMapper.insertSelective(userAmountRecords);

            packetIdList.add(voiceRedPacket.getId());
        }
        _log.info("本次退还余额的红包列表：" + StringUtils.join(packetIdList,","));
    }
}
