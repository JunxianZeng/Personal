package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.text.BadLocationException;
import javax.swing.text.Element;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import base.Cmd;
import base.SendCmd;
import base.SendMsg;
import vo.AccountVo;

public class ChatUI extends JFrame implements ActionListener,ItemListener{

	JLabel title;
	JTextPane txtReceive,txtSend;
	JButton btnSend,btnClose;
	JButton btnShake,btnFile,btnColor,btnFace;
	JComboBox cbFont,cbSize;
	AccountVo myInfo,friendInfo;
	Vector<AccountVo> familyGroup;
	String sFont[] = {"����","����","����","����"};
	String sSize[]={"8","10","12","14","16","18","24","28","32","36","72"};
	Font font;
	public ChatUI(AccountVo myInfo,AccountVo friendInfo,Vector<AccountVo> familyGroup) {
		String str =myInfo.getNickName()+"("+myInfo.getQqCode() +")��";
		str += friendInfo.getNickName()+"("+friendInfo.getQqCode()+")��������...";
		setTitle(str);
		this.myInfo = myInfo;
		this.friendInfo = friendInfo;
		this.familyGroup = familyGroup;
		setIconImage(new ImageIcon(friendInfo.getHeadImg()).getImage());
		title = new JLabel(str,new ImageIcon(friendInfo.getHeadImg()),SwingConstants.LEFT);
		title.setForeground(Color.WHITE);
		title.setOpaque(false);
		JLabel titlebg = new JLabel(new ImageIcon("images/2.jpg"));
		titlebg.setLayout(new FlowLayout(FlowLayout.LEFT));
		titlebg.add(title);
		add(titlebg,BorderLayout.NORTH);
		JPanel centerPanel = new JPanel(new GridLayout(2,1,1,1));
		txtReceive = new JTextPane();
		centerPanel.add(new JScrollPane(txtReceive));
		/*����3����
		 * 1.��������ɫ������ȿؼ�
		 * 2.���Ϳؼ�
		 * 3.���Ͱ�ť���رհ�ť
		 * 
		 */
		JPanel sendPanel = new JPanel(new BorderLayout());
		JLabel btnPanel = new JLabel(new ImageIcon("images/11.jpg"));
		btnPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		cbFont = new JComboBox(sFont);
		cbSize = new JComboBox(sSize);
		cbFont.addItemListener(this);
		cbSize.addItemListener(this);
		btnShake = new JButton(new ImageIcon("images/zd.png"));
		//���ð�ť�Ĵ�С��ͼƬһ��
		btnShake.setMargin(new Insets(0,0,0,0));
		btnFile = new JButton("�ļ�");
		btnColor = new JButton("��ɫ");
		btnFace = new JButton(new ImageIcon("images/sendFace.png"));
		btnFace.setMargin(new Insets(0,0,0,0));
		btnShake.addActionListener(this);
		btnFile.addActionListener(this);
		btnColor.addActionListener(this);
		btnFace.addActionListener(this);
		
		btnPanel.add(cbFont);
		btnPanel.add(cbSize);
		btnPanel.add(btnColor);
		btnPanel.add(btnShake);
		btnPanel.add(btnFace);
		btnPanel.add(btnFile);
		sendPanel.add(btnPanel,BorderLayout.NORTH);
		txtSend = new JTextPane();
		sendPanel.add(txtSend,BorderLayout.CENTER);
		btnSend = new JButton("����(S)");
		btnSend.setMnemonic('S');
		btnClose = new JButton("�ر�(X)");
		btnClose.setMnemonic('X');
		btnSend.addActionListener(this);
		btnClose.addActionListener(this);
		JLabel bottombg = new JLabel(new ImageIcon("images/11.jpg"));
		bottombg.setLayout(new FlowLayout(FlowLayout.RIGHT));
		bottombg.add(btnSend);
		bottombg.add(btnClose);
		sendPanel.add(bottombg,BorderLayout.SOUTH);
		centerPanel.add(new JScrollPane(sendPanel));
		add(centerPanel);
		JLabel lblboy = new JLabel(new ImageIcon("images/6.jpg"));
		add(lblboy,BorderLayout.EAST);
		setSize(700, 500);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}
	//�ѷ��Ϳ�������ύ�����տ�ͬʱ������Ϳ������
	public  void appendView(String name, StyledDocument xx)throws BadLocationException {
		//��ȡ���տ���ĵ������ݣ�
		StyledDocument vdoc = txtReceive.getStyledDocument();//��ȡ���տ������
		
		// ��ʽ��ʱ��
		Date date = new Date();//��ȡϵͳ��ǰʱ��
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); //������ʾʱ����ĸ�ʽ
		String time = sdf.format(date);//��ȡʱ����
		//����һ�����Լ���
		SimpleAttributeSet as = new SimpleAttributeSet();
		// ��ʾ˭˵
		//vdoc.getLength()��ȡ���տ��е�ԭ�����ݵĳ���
		String s =name + "    " + time + "\n";
//		saveRecord(name,s);//���������¼
		vdoc.insertString(vdoc.getLength(), s, as);
		int end = 0;
		//������ʾ������
		while (end < xx.getLength()) {
			// ���һ��Ԫ��
			Element e0 = xx.getCharacterElement(end);
			//��ȡ��Ӧ�ķ��
			SimpleAttributeSet as1 = new SimpleAttributeSet();
			StyleConstants.setForeground(as1, StyleConstants.getForeground(e0.getAttributes()));
			StyleConstants.setFontSize(as1, StyleConstants.getFontSize(e0.getAttributes()));
			StyleConstants.setFontFamily(as1, StyleConstants.getFontFamily(e0.getAttributes()));
			//��ȡ��Ԫ�ص�����
			s = e0.getDocument().getText(end, e0.getEndOffset() - end);
			// ��Ԫ�ؼӵ��������
			if("icon".equals(e0.getName())){
				vdoc.insertString(vdoc.getLength(), s, e0.getAttributes());
			}
			else{
				vdoc.insertString(vdoc.getLength(), s, as1);
//				saveRecord(name,s+"\n");//���������¼
			}
			//getEndOffset�����������ǻ�ȡ��ǰԪ�صĳ���
			end = e0.getEndOffset(); 
		}
		// ����һ������
		vdoc.insertString(vdoc.getLength(), "\n", as);
		
		// ������ʾ��ͼ���ַ���λ�����ĵ���β���Ա���ͼ����
		txtReceive.setCaretPosition(vdoc.getLength());
	}
	public static void main(String[] args) {
		new ChatUI(null,null,null);
	}
	public void shake(){
		//��������
		int x = this.getLocation().x;
		int y = this.getLocation().y;
		for(int i=0;i<20;i++){
			if(i%2==0){
				this.setLocation(x+2, y+2);
			}else{
				this.setLocation(x-2, y-2);
			}
			try {
				Thread.sleep(50);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnShake){
			//������Ϣ
			SendMsg msg = new SendMsg();
			msg.cmd = Cmd.CMD_SHAKE;
			msg.myInfo = myInfo;
			msg.friendInfo = friendInfo;
			SendCmd.send(msg);
			shake();
		}else if(e.getSource()==btnColor){
			JColorChooser colordlg = new JColorChooser();
			//����ɫ�Ի��򣬲��һ�ȡѡ�е���ɫ
			Color color=JColorChooser.showDialog(this, "��ѡ��������ɫ", Color.BLACK);
			//���÷����ı����������ɫ
			txtSend.setForeground(color);
			
		}else if(e.getSource()==btnFace){
			//�򿪱��鴰�ڣ�ѡ�����ͼ��
			int x,y;
			x=this.getLocation().x+220;
			y=this.getLocation().y-28;
			new BqUI(this,x,y);
		}else if(e.getSource()==btnFile){
			FileDialog dlg = new FileDialog(this,"��ѡ��Ҫ���͵��ļ�(64K����)",FileDialog.LOAD);
			dlg.show();
			String filename = dlg.getDirectory() + dlg.getFile();
			try {
				FileInputStream fis = new FileInputStream(filename);
				int size = fis.available();
				byte b[] = new byte[size];
				fis.read(b);
				SendMsg msg = new SendMsg();
				msg.cmd = Cmd.CMD_FILE;
				msg.myInfo=myInfo;
				msg.friendInfo = friendInfo;
				msg.b = b;
				msg.fileName = dlg.getFile();
				SendCmd.send(msg);
				
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			System.out.println(filename);
		}else if(e.getSource()==btnSend){
			if(txtSend.getText().equals("")){
				JOptionPane.showMessageDialog(this, "��������Ҫ���͵����ݡ�");
				return;
			}
			try {
				appendView(myInfo.getNickName(), txtSend.getStyledDocument());
				if(friendInfo.getGroupName()!=null && friendInfo.getGroupName().equals(Cmd.GROUPNAME[2])){
					SendCmd.sendAll(familyGroup, myInfo, Cmd.CMD_SEND,txtSend.getStyledDocument());
				}else{
					SendMsg msg= new SendMsg();
					msg.cmd = Cmd.CMD_SEND;
					msg.myInfo = myInfo;
					msg.friendInfo = friendInfo;
					msg.doc = txtSend.getStyledDocument();
					SendCmd.send(msg);
				}
				txtSend.setText("");
			} catch (BadLocationException e1) {
				e1.printStackTrace();
			}
		}else if(e.getSource()==btnClose){
			dispose();
		}
	}
	public void setFont(){
		String sf=sFont[cbFont.getSelectedIndex()];
		String size = sSize[cbSize.getSelectedIndex()];
		font = new Font(sf,Font.PLAIN,Integer.parseInt(size));
		//���÷����ı��������
		txtSend.setFont(font);
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getSource()==cbFont){
			setFont();
		}else if(e.getSource()==cbSize){
			setFont();
		}
	}
}
