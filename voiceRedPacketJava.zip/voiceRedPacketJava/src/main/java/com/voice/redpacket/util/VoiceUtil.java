package com.voice.redpacket.util;

import it.sauronsoftware.jave.DefaultFFMPEGLocator;
import net.sf.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * Created by ZhaoYuJie on 2018/1/15.
 */
public class VoiceUtil {
    /**
     *
     * @param silkPath silk文件的路径
     * @return 音频转换出的文字内容
     */
    public static String convertSilkToText(String silkPath){
        String pcmPath = silkPath.substring(0,silkPath.lastIndexOf("."))+".pcm";
        String wavPath = silkPath.substring(0,silkPath.lastIndexOf("."))+".wav";

        //获取当前操作系统
        String os = System.getProperty("os.name").toLowerCase();

        if(os.indexOf("linux")>=0){
            wavPath = convertSilkToWav(silkPath);
        }else if(os.indexOf("windows")>=0){
            convertSilkToPcm(silkPath,pcmPath);
            convertPcmToWav(pcmPath,wavPath);
        }else{
            return null;
        }
        return wavToWords(wavPath);
    }
    /**
     * 将silk文件转换为pcm文件（用于windows系统）
     * @param silkPath 输入的silk格式的音频文件路径，例如D:/silk.silk
     * @param pcmPath 输出的pcm格式的音频文件路径，例如D:/result.pcm
     */
    private static void convertSilkToPcm(String silkPath,String pcmPath){
        File silk = new File(silkPath);//silk文件
        File pcm = new File(pcmPath);//转码后的pcm文件
        try {
            //silk转pcm，“-Fs_API 16000”设置输入音频的采样率为16000
            String cmd = "cmd.exe /c " + ConfigUtil.getValue("windows_silk_convert_path") +" " + silk.getAbsolutePath() + " " + pcm.getAbsolutePath() + " -Fs_API 16000";
            Runtime.getRuntime().exec(cmd);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 将pcm文件转换为wav文件（用于windows系统）
     * @param pcmPath 需要转码的pcm文件路径，例如D:/result.pcm
     * @param wavPath 转码后的wav文件路径，例如D:/result.wav
     */
    private static void convertPcmToWav(String pcmPath,String wavPath){
        File pcm = new File(pcmPath);
        File wav= new File(wavPath);

        Process exec = null;
        try {
            //pcm转wav或其它格式
            String cmd = "cmd /c ffmpeg.exe -loglevel quiet -y -f s16le -ar 16000 -ac 1 -i " + pcm.getAbsolutePath() + " " + wav.getAbsolutePath();
            exec = Runtime.getRuntime().exec(cmd);
            exec.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * silk文件转wav文件（用于linux）<br/>
     * 需要修改converter.sh脚本的第70行，将ffmpeg -y -f s16le -ar 24000 -ac 1 -i "$1.pcm" "${1%.*}.$2" > /dev/null 2>&1里面的24000改成16000（采样率）
     * @param silkPath silk文件路径
     * @return 返回wav文件路径
     */
    private static String convertSilkToWav(String silkPath) {
        File silk = new File(silkPath);//silk文件
        //执行converter.sh，silk转wav，这里执行后，会在tmp/silk/目录下生成wav音频文件
        Process exec = null;
        try {
            exec = Runtime.getRuntime().exec("sh " + ConfigUtil.getValue("linux_silk_convert_path") + " " + silk.getAbsolutePath() + " wav");
            exec.waitFor();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String wavPath = silkPath.substring(0,silkPath.lastIndexOf("."))+".wav";
        return wavPath;
    }

    /**
     * 将wav文件转换为文字内容
     * @param wavPath
     * @return
     */
    private static String  wavToWords(String wavPath){
        //讯飞语音识别接口识别wav音频文件，转成文字返回
        SRTool sr = new SRTool();
        String words = null;
        try {
            words = sr.voice2words(wavPath);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("讯飞语音返回的json串："+words);
        String result = sr2words(words);
        System.out.println("讯飞识别的语音结果："+result);
        return result;
    }

    private static String sr2words(String jsonString){
        StringBuffer sb = new StringBuffer();
        String[] split = jsonString.split("}]}]}");
        for (int i = 0; i < split.length; i++) {
            String s = split[i] + "}]}]}";
            System.out.println(s);
            Map parse = JSONObject.fromObject(s);
            List<Map> ws = (List<Map>) parse.get("ws");
            for (int i1 = 0; i1 < ws.size(); i1++) {
                List<Map> cw = (List<Map>)ws.get(i1).get("cw");
                String w = cw.get(0).get("w").toString();
                sb.append(w);
            }

        }
        return sb.toString();
    }

    /**
     * 过滤掉字符串中除了中英文字符数字之外的字符
     * @param str
     * @return 返回过滤后的字符串
     */
    public static String delRedundantCharacters(String str){
        return str.replaceAll("(?i)[^a-zA-Z0-9\u4E00-\u9FA5]", "");
    }

    public static void main(String[] args) {
//        String content = convertSilkToText("D:\\upload\\voiceDir\\8\\oHosW0Yzg79GVpkMVl18yvZtvDzA\\b3c576d40d8b414b895afafd42bc118b.silk");
//        System.out.println("音频文件解析结果："+content);
//        System.out.println(delRedundantCharacters("你 好。"));
        System.out.println(System.getProperty("java.io.tmpdir"));
//        InputStream resourceAsStream = DefaultFFMPEGLocator.class.getResourceAsStream("native/ffmpeg-amd64.exe");
        InputStream resourceAsStream = DefaultFFMPEGLocator.class.getResourceAsStream("activation-1.1.jar");
        System.out.println(resourceAsStream);

    }

}
