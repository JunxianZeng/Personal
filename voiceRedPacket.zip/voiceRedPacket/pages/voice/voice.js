//获取应用实例
const app = getApp()
const innerAudioContext = wx.createInnerAudioContext()
const { Actionsheet, extend } = require('../../dist/index');
const util = require('../../utils/util.js')

Page(
  extend({}, Actionsheet, {
    data: {
      baseActionsheet: {
        show: false,
        cancelText: '取消',
        closeOnClickOverlay: true,
        componentId: 'baseActionsheet',
        actions: [{
          name: '分享给好友',
          openType: 'share'
        }, {
          name: '生成分享图片',
          loading: false
        }]
      },
      packetId: '',
      drawDisabled: true,
      btnText: '',
      btnType: 'default',
      text: '',
      totalMoney: 0,
      num: 0,
      drawNum: 0,
      drawList: [],
      isPlaying: false,
      providerUserInfo: {},
      j: 1,//帧动画初始图片
      isSpeaking: false,//是否正在说话
    },


    toggleActionsheet() {
      this.setData({
        'baseActionsheet.show': true
      });
    },

    handleZanActionsheetCancel({ componentId }) {
      this.setData({
        [`${componentId}.show`]: false
      });
    },

    handleZanActionsheetClick({ componentId, index }) {
      console.log(`item index ${index} clicked`);

      // 如果是分享按钮被点击, 不处理关闭
      if (index === 0) {
        this.setData({
          [`${componentId}.show`]: false
        });
        return;
      }

      if (index === 1) {
        this.getWxCode(componentId, index);
      }

      // this.setData({
      //   [`${componentId}.actions[${index}].loading`]: true
      // });

      // setTimeout(() => {
      //   this.setData({
      //     [`${componentId}.show`]: false,
      //     [`${componentId}.actions[${index}].loading`]: false
      //   });
      // }, 1500);
    },
    onLoad: function (option) {
      console.log("voice页面收到参数：" + option.packetId)
      this.setData({
        packetId: option.packetId
      })

      this.refreshData();

      innerAudioContext.onPlay(() => {
        console.log('开始播放')
      })
      innerAudioContext.onStop((res) => {
        console.log('停止播放')
        var drawList = this.data.drawList;
        for (var i = 0; i < drawList.length; i++) {
          drawList[i].duration2 = drawList[i].duration + "''"; //duration2用于显示
        }

        this.setData({
          drawList: drawList,
          isPlaying: false
        })
      })
      innerAudioContext.onEnded(() => {
        console.log('播放结束')
        var drawList = this.data.drawList;
        for (var i = 0; i < drawList.length; i++) {
          drawList[i].duration2 = drawList[i].duration + "''"; //duration2用于显示
        }

        this.setData({
          drawList: drawList,
          isPlaying: false
        })
      })
      wx.showShareMenu({
        withShareTicket: true
      })

    },
    // 按钮按下
    touchdown: function () {
      var that = this;
      if (that.data.drawDisabled != false) {
        return;
      }
      speaking.call(this);
      this.setData({
        isSpeaking: true
      })
      console.log("[Console log]:Touch down!Start recording!");
      wx.startRecord({
        success: function (res) {
          var tempFilePath = res.tempFilePath;
          console.log("[Console log]:Record success!File path:" + tempFilePath);
          if (tempFilePath == null) {
            console.log("[Console log]:File path do not exist!");
            wx.showModal({
              title: '录音文件不存在',
              content: '再试一次吧！',
              showCancel: false,
              confirmText: '确定',
              confirmColor: '#09BB07',
            })
            return;
          }
          wx.showLoading({
            title: '语音识别中...',
          })
          wx.uploadFile({
            url: app.globalData.baseUrl + 'uploadVoice.htm?packetId=' + that.data.packetId,
            filePath: tempFilePath,
            name: 'file',
            formData: {
              packetId: that.data.packetId,
              sessionId: wx.getStorageSync("sessionId")
            },
            header: { 'content-type': 'multipart/form-data' },
            success: function (res) {
              wx.hideLoading();

              var retCode;
              var retMsg;

              if (typeof res.data == 'string') {
                res.data = JSON.parse(res.data);
              }
              retCode = res.data.retCode;
              retMsg = res.data.retMsg;

              if (retCode == 0) { //成功
                wx.showToast({
                  title: retMsg,
                  icon: 'success',
                  duration: 2000
                })
                //TODO 刷新语音列表
                that.refreshData();
              } else {
                wx.showModal({
                  content: retMsg,
                  showCancel: false
                });
                return;
              }
            },
            fail: function (res) {
              console.log("[Console log]:Voice upload failed:" + res.errMsg);
              wx.hideLoading();
              wx.showModal({
                title: '语音识别失败',
                content: '请稍后再试！',
                showCancel: false,
                confirmText: '确定',
                confirmColor: '#09BB07',
              })
            }
          })

        },
        fail: function () {
          console.log("[Console log]:Record failed!");
          wx.showModal({
            title: '录音失败',
            content: '换根手指再试一次！',
            showCancel: false,
            confirmText: '确定',
            confirmColor: '#09BB07',
          })
        },
      });
      setTimeout(function () {
        //结束录音  
        wx.stopRecord()
      }, 60000)
    },
    // 按钮松开
    touchup: function () {
      var that = this;
      if (that.data.drawDisabled != false) {
        return;
      }
      this.setData({
        isSpeaking: false,
      })
      clearInterval(this.timer)
      wx.stopRecord();
      console.log("[Console log]:Touch up!Stop recording!");
    },
    playOrPause: function (e) {
      var that = this;
      if (this.data.isPlaying) {
        innerAudioContext.stop();
        this.setData({
          isPlaying: false
        })

        that.data.drawList[e.currentTarget.dataset.index].duration2 = that.data.drawList[e.currentTarget.dataset.index].duration + "''";
        that.setData({
          drawList: that.data.drawList
        })
      } else {
        innerAudioContext.src = e.currentTarget.dataset.src;
        innerAudioContext.play();
        this.setData({
          isPlaying: true
        })
        that.data.drawList[e.currentTarget.dataset.index].duration2 = "播放中";
        that.setData({
          drawList: that.data.drawList
        })
        //this.countDown(e.currentTarget.dataset.index, e.currentTarget.dataset.duration);
      }

    },
    countDown: function (index, time) { //time倒计时的秒数
      if (!this.data.isPlaying) {
        return;
      }
      var that = this;
      if (time > 1) {
        time--;
        that.data.drawList[index].duration2 = time;
        that.setData({
          drawList: that.data.drawList
        })
        setTimeout(function () { that.countDown(index, time) }, 1000);
      } else {
        that.data.drawList[index].duration2 = that.data.drawList[index].duration;
        that.setData({
          drawList: that.data.drawList,
          isPlaying: false
        })
      }
    },
    toIndex: function () {
      wx.switchTab({
        url: '../index/index',
      })
    },
    onShareAppMessage: function (res) {
      var that = this;
      if (res.from === 'button') {
        // 来自页面内转发按钮
        console.log(res.target)
        this.setData({
          'baseActionsheet.show': false
        });
      }
      sleep.call(this, 500);
      return {
        title: '快来领取语音红包',
        path: '/pages/voice/voice?packetId=' + this.data.packetId,
        success: function (res) {
          // 转发成功
          console.log("转发成功")
          wx.showModal({
            content: '转发成功',
            showCancel: false
          })
        },
        fail: function (res) {
          // 转发失败
          console.log("转发失败")
        }
      }
    },
    getWxCode: function (componentId, index) {
      var that = this;


      that.setData({
        [`${componentId}.actions[${index}].loading`]: true
      });


      wx.request({
        url: app.globalData.baseUrl + 'getWxCodeUrl.htm?packetId=' + that.data.packetId,
        success: function (res) {
          console.log(res.data);
          if (res.data.retCode == 0) { //成功
            var imgUrl = app.globalData.baseUrl + that.data.packetId + ".png";
            wx.downloadFile({
              url: imgUrl,
              success: function (res) {
                that.setData({
                  [`${componentId}.show`]: false,
                  [`${componentId}.actions[${index}].loading`]: false
                });
                var tempFilePath = res.tempFilePath;
                wx.saveImageToPhotosAlbum({
                  filePath: tempFilePath,
                  success: function (res) {
                    wx.showModal({ // 保存成功后记得提醒用户二维码已经存到他的手机相册了哦
                      title: '小程序码已保存到相册',
                      content: '快去分享到朋友圈吧',
                      showCancel: false
                    })
                  },
                  fail: function (err) {
                    console.log("保存到相册失败：" + err.errMsg)
                    if(err.errMsg === "saveImageToPhotosAlbum:fail:auth denied") {
                      wx.showModal({
                        title: '温馨提示',
                        content: '由于您之前拒绝授权导致保存到相册失败',
                        confirmText: "允许授权",
                        cancelText: "拒绝到底",
                        success: function (res) {
                          console.log(res);
                          if (res.confirm) {
                            wx.openSetting({
                              success(settingdata) {
                                console.log(settingdata)
                                if (settingdata.authSetting['scope.writePhotosAlbum']) {
                                  wx.showModal({ // 保存成功后记得提醒用户二维码已经存到他的手机相册了哦
                                    title: '授权成功',
                                    content: '快去生成分享图片吧！',
                                    showCancel: false
                                  })
                                }
                              }
                            })
                          } else {
                            console.log('用户拒绝授权scope.writePhotosAlbum')
                          }
                        }
                      })
                      
                    }
                    
                  }

                })
                
              }
            })
          }
        }
      })
    },
    toShare: function () {
      wx.showActionSheet({
        itemList: ['分享给好友', '生成分享图片'],
        success: function (res) {
          if (!res.cancel) {
            if (res.tapIndex == 0) {

            } else if (res.tapIndex == 1) {

            }
          }
        }
      });
    },
    refreshData: function () {
      var that = this;
      wx.request({
        url: app.globalData.baseUrl + 'getVoiceRedPacket.htm?packetId=' + that.data.packetId,
        success: function (res) {
          var openId = res.data.voiceRedPacket.openId;
          var text = res.data.voiceRedPacket.text;
          var fee = res.data.voiceRedPacket.fee;
          var num = res.data.voiceRedPacket.num;
          var drawNum = res.data.voiceRedPacket.drawNum;
          var createTime = res.data.voiceRedPacket.createTime;
          var _type = res.data.voiceRedPacket.type;
          var drawList = res.data.drawList;
          var providerUserInfo = res.data.providerUserInfo;

          if (_type == 2) {
            wx.showModal({
              content: '红包类型不符',
              showCancel: false
            });
            return;
          }

          for (var i = 0; i < drawList.length; i++) {
            drawList[i].duration2 = drawList[i].duration + "''"; //duration2用于显示
            drawList[i].src = app.globalData.baseUrl + that.data.packetId + "/" + drawList[i].openId + "/" + drawList[i].id + ".wav";
            drawList[i].drawTime = util.formatSimpleTime(new Date(drawList[i].drawTime.time));
            drawList[i].drawFee = (drawList[i].drawFee / 100).toFixed(2);
          }

          that.setData({
            text: text,
            totalMoney: fee / 100,
            num: num,
            drawNum: drawNum,
            drawList: drawList,
            providerUserInfo: providerUserInfo
          })

          if (drawNum >= num) {
            that.setData({
              btnText: '赏金都被领完了',
              drawDisabled: true,
              btnType: 'default'
            })
          } else if (new Date().getTime() >= createTime.time + 24 * 60 * 60 * 1000) {
            that.setData({
              btnText: '红包已过期',
              drawDisabled: true,
              btnType: 'default'
            })
          } else {
            that.setData({
              btnText: '长按说口令',
              drawDisabled: false,
              btnType: 'primary'
            })
          }

        }
      })
    }

  })


)

//麦克风帧动画
function speaking() {
  var _this = this;
  //话筒帧动画
  var i = 1;
  this.timer = setInterval(function () {
    i++;
    i = i % 5;
    _this.setData({
      j: i
    })
  }, 200);
}

function sleep(n) {
  var start = new Date().getTime();
  while (true) if (new Date().getTime() - start > n) break;
}
