package com.voice.redpacket.web;

import com.voice.redpacket.constant.Constant;
import com.voice.redpacket.domain.PaymentPo;
import com.voice.redpacket.domain.VoiceRedPacket;
import com.voice.redpacket.domain.WxPayInfo;
import com.voice.redpacket.service.IUserInfoService;
import com.voice.redpacket.service.IVoiceRedPacketService;
import com.voice.redpacket.service.IWxPayInfoService;
import com.voice.redpacket.util.*;
import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
@Controller
@RequestMapping("/order")
public class OrderController {
	private static Logger _log = LoggerFactory
			.getLogger(OrderController.class);
	@Resource
	private IUserInfoService userInfoService;
	@Resource
	private IVoiceRedPacketService voiceRedPacketService;
	@Resource
	private IWxPayInfoService wxPayInfoService;


	/**
	 * 微信小程序的下单接口
	 * @param sessionId
	 * @param fee 金额
     * @return
     */
	@RequestMapping(value = "/unifiedorder", method = RequestMethod.POST)
	@ResponseBody
	public String unifiedorder(@RequestParam String sessionId,@RequestParam String text, @RequestParam int fee,
							   @RequestParam int num,@RequestParam int limitTime,@RequestParam short shareScope,@RequestParam short type,HttpServletRequest request) {
		JSONObject resultJO = new JSONObject();

		String sessionValue = JedisUtil.get(sessionId);
		if (StringUtils.isEmpty(sessionValue)) {
			_log.info("微信sessionId无效:{}", sessionId);
			resultJO.put(Constant.RET_CODE, Constant.RET_CODE_UNLONGIN);
			resultJO.put(Constant.RET_MSG, "未登录");
			return resultJO.toString();
		}

//		if(1==1){
//			resultJO.put(Constant.RET_CODE, 1);
//			resultJO.put(Constant.RET_MSG, "暂不支持微信支付");
//			return resultJO.toString();
//		}

		String openId = sessionValue.split("#")[1];

		String body = "语音红包-发放赏金";
		String appid = Constant.WX_XIAOCHENGXU_APPID;//小程序ID
		String mch_id = Constant.WX_XIAOCHENGXU_MCH_ID;//商户号
		String nonce_str = RandomStringGenerator.getRandomStringByLength(32);//随机字符串
		String now = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String code = PayUtil.createCode(8);
		String out_trade_no = mch_id+now+code;//商户订单号
		String spbill_create_ip = IpUtility.getRemoteAddr(request);//终端IP
		String notify_url = Constant.WX_XIAOCHENGXU_NOTIFY_URL;//通知地址
		String trade_type = "JSAPI";//交易类型

		//插入订单记录
		WxPayInfo wxPayInfo = new WxPayInfo();
		wxPayInfo.setAppId(appid);
		wxPayInfo.setMchId(mch_id);
		wxPayInfo.setOpenId(openId);
		wxPayInfo.setBody(body);

		wxPayInfo.setSpBillCreateIP(spbill_create_ip);
		wxPayInfo.setNotifyUrl(notify_url);
		wxPayInfo.setStatus(0);
		wxPayInfo.setTradeType(trade_type);
		wxPayInfo.setOutTradeNo(out_trade_no);
		wxPayInfo.setTotalFee(fee);
		wxPayInfoService.save(wxPayInfo);


		PaymentPo paymentPo = new PaymentPo();
		paymentPo.setAppid(appid);
		paymentPo.setMch_id(mch_id);
		paymentPo.setNonce_str(nonce_str);
		paymentPo.setBody(body);
		paymentPo.setOut_trade_no(out_trade_no);
		paymentPo.setTotal_fee(fee+""); //订单总金额，单位为分
		paymentPo.setSpbill_create_ip(spbill_create_ip);
		paymentPo.setNotify_url(notify_url);
		paymentPo.setTrade_type(trade_type);
		paymentPo.setOpenid(openId);
		// 把请求参数打包成数组
		Map<String, String> sParaTemp = new HashMap<>();
		sParaTemp.put("appid", paymentPo.getAppid());
		sParaTemp.put("mch_id", paymentPo.getMch_id());
		sParaTemp.put("nonce_str", paymentPo.getNonce_str());
		sParaTemp.put("body",  paymentPo.getBody());
		sParaTemp.put("out_trade_no", paymentPo.getOut_trade_no());
		sParaTemp.put("total_fee",paymentPo.getTotal_fee());
		sParaTemp.put("spbill_create_ip", paymentPo.getSpbill_create_ip());
		sParaTemp.put("notify_url",paymentPo.getNotify_url());
		sParaTemp.put("trade_type", paymentPo.getTrade_type());
		sParaTemp.put("openid", paymentPo.getOpenid());
		// 除去数组中的空值和签名参数
		Map<String, String> sPara = PayUtil.paraFilter(sParaTemp);
		String prestr = PayUtil.createLinkString(sPara); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		String key = "&key="+Constant.WX_XIAOCHENGXU_MCH_KEY; // 商户支付密钥
		//MD5运算生成签名
		String mysign = PayUtil.sign(prestr, key, "utf-8").toUpperCase();
		paymentPo.setSign(mysign);
		//打包要发送的xml
		String respXml = MessageUtil.messageToXML(paymentPo);
		// 打印respXml发现，得到的xml中有“__”不对，应该替换成“_”
		respXml = respXml.replace("__", "_");
		_log.info("打印respXml：\n{}",respXml);
		String url = Constant.WX_UNIFIED_ORDER_URL;//统一下单API接口链接
		String param = respXml;

		String result =PayUtil.httpRequest(url, "POST", param);
		// 将解析结果存储在HashMap中
		Map<String,String> map = new HashMap<>();
		InputStream in=new ByteArrayInputStream(result.getBytes());
		// 读取输入流
		SAXReader reader = new SAXReader();
		Document document = null;
		try {
			document = reader.read(in);
			// 得到xml根元素
			Element root = document.getRootElement();
			// 得到根元素的所有子节点
			//@SuppressWarnings("unchecked")
			List<Element> elementList = root.elements();
			for (Element element : elementList) {
				map.put(element.getName(), element.getText());
			}
			// 返回信息
			String return_code = map.get("return_code"); //返回状态码
			String return_msg = map.get("return_msg"); //返回信息

			if(!"SUCCESS".equals(return_code)){
				_log.info("下单失败：return_code={}, return_msg={}" ,return_code,return_msg);

				wxPayInfo.setStatus(2); //下单失败
				wxPayInfo.setReturnCode(return_code);
				wxPayInfo.setReturnMsg(return_msg);
				wxPayInfoService.update(wxPayInfo);

				resultJO.put(Constant.RET_CODE, 1);
				resultJO.put(Constant.RET_MSG, return_code+":"+return_msg);
				return resultJO.toString();
			}

			String result_code = map.get("result_code"); //返回业务结果
			if(!"SUCCESS".equals(result_code)){
				String err_code = map.get("err_code");
				String err_code_des = map.get("err_code_des");
				_log.info("下单失败：result_code={}, err_code={}, err_code_des={}" ,result_code,err_code,err_code_des);

				wxPayInfo.setStatus(2); //下单失败
				wxPayInfo.setReturnCode(return_code);
				wxPayInfo.setReturnMsg(return_msg);
				wxPayInfo.setErrCode(err_code);
				wxPayInfo.setErrCodeDes(err_code_des);
				wxPayInfoService.update(wxPayInfo);

				resultJO.put(Constant.RET_CODE, 2);
				resultJO.put(Constant.RET_MSG, result_code+":"+err_code+";"+err_code_des);
				return resultJO.toString();
			}

			String prepay_id = map.get("prepay_id");//返回的预付单信息

			wxPayInfo.setStatus(1); //下单成功
			wxPayInfo.setReturnCode(return_code);
			wxPayInfo.setReturnMsg(return_msg);
			wxPayInfo.setPrepayId(prepay_id);
			wxPayInfoService.update(wxPayInfo);

			//创建语音红包
			VoiceRedPacket voiceRedPacket = new VoiceRedPacket();
			voiceRedPacket.setOpenId(openId);
			voiceRedPacket.setText(text);
			voiceRedPacket.setFee(fee);
			voiceRedPacket.setNum(num);
			voiceRedPacket.setServerFee(fee
					* ConfigUtil.getInteger("serverFeeRate")/100);
			voiceRedPacket.setCreateTime(new Date());
			voiceRedPacket.setPayId(wxPayInfo.getPayId());
			if(limitTime > 0){
				voiceRedPacket.setLimitTime(limitTime);
			}
			voiceRedPacket.setType(type);
			voiceRedPacket.setPayType((short) 1); //微信支付
			voiceRedPacket.setPayStatus((short) 0); //未支付
			voiceRedPacket.setShareScope(shareScope);

			voiceRedPacketService.createVoice(voiceRedPacket);

			JSONObject paymentJson=new JSONObject() ;
			String nonceStr=RandomStringGenerator.getRandomStringByLength(32);
			paymentJson.put("nonceStr", nonceStr);
			paymentJson.put("package", "prepay_id="+prepay_id);
			Long timeStamp= System.currentTimeMillis()/1000;
			paymentJson.put("timeStamp", timeStamp+"");
			paymentJson.put("signType", "MD5");
			String stringSignTemp = "appId="+appid+"&nonceStr=" + nonceStr + "&package=prepay_id=" + prepay_id+ "&signType=MD5&timeStamp=" + timeStamp;
			//再次签名
			String paySign=PayUtil.sign(stringSignTemp, "&key="+Constant.WX_XIAOCHENGXU_MCH_KEY, "utf-8").toUpperCase();
			paymentJson.put("paySign", paySign);

			resultJO.put("paymentJson",paymentJson); //用于微信小程序发起支付
			resultJO.put("packetId",voiceRedPacket.getId());

		} catch (DocumentException e) {
			resultJO.put(Constant.RET_CODE, 100);
			resultJO.put(Constant.RET_MSG, "解析订单结果失败" + e.getMessage());
			e.printStackTrace();
		}

		resultJO.put(Constant.RET_CODE, Constant.RET_CODE_OK);

		return resultJO.toString();
	}

	/**
	 * map转string
	 * @param map
	 * @return
     */
	public static String transMapToString(Map map){
		java.util.Map.Entry entry;
		StringBuffer sb = new StringBuffer();
		for(Iterator iterator = map.entrySet().iterator(); iterator.hasNext();)
		{
			entry = (java.util.Map.Entry)iterator.next();
			sb.append(entry.getKey().toString()).append( "=" ).append(null==entry.getValue()?"":
					entry.getValue().toString()).append (iterator.hasNext() ? "\n" : "");
		}
		return sb.toString();
	}

	@RequestMapping("/wxPayNotify")
	@ResponseBody
	public String wxPayNotify(HttpServletRequest request) throws Exception {
		HashMap returnMap = new HashMap();

		HashMap resultMap = MessageUtil.parseXML(request);

		_log.info("微信支付回调参数："+transMapToString(resultMap));


		if(!"SUCCESS".equalsIgnoreCase((String) resultMap.get("return_code"))){
			returnMap.put("return_code","FAIL");
			returnMap.put("return_msg",resultMap.get("return_msg"));
			return MessageUtil.messageToXML(returnMap);
		}

		String out_trade_no = (String) resultMap.get("out_trade_no");
		WxPayInfo wxPayInfo = wxPayInfoService.findByTradeNo(out_trade_no);

		if(wxPayInfo == null){
			returnMap.put("return_code","FAIL");
			returnMap.put("return_msg","商户订单号不存在");
			return MessageUtil.messageToXML(returnMap);
		}

		int total_fee = Integer.valueOf(resultMap.get("total_fee").toString()) ;
		if(total_fee != wxPayInfo.getTotalFee().intValue()){
			returnMap.put("return_code","FAIL");
			returnMap.put("return_msg","金额错误");
			return MessageUtil.messageToXML(returnMap);
		}

		// 除去数组中的空值和签名参数
		Map<String, String> sPara = PayUtil.paraFilter(resultMap);
		String prestr = PayUtil.createLinkString(sPara); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		String key = "&key="+Constant.WX_XIAOCHENGXU_MCH_KEY; // 商户支付密钥
		//MD5运算生成签名
		String resultSign = PayUtil.sign(prestr, key, "utf-8").toUpperCase();

		String sign = (String) resultMap.get("sign");
		if(!sign.equals(resultSign)){
			returnMap.put("return_code","FAIL");
			returnMap.put("return_msg","签名错误");
			return MessageUtil.messageToXML(returnMap);
		}

		if(wxPayInfo.getStatus() == 3){
			returnMap.put("return_code","SUCCESS");
			returnMap.put("return_msg","已成功处理过");
			return MessageUtil.messageToXML(returnMap);
		}

		//支付成功
		wxPayInfo.setStatus(3);
		wxPayInfo.setTransactionId(resultMap.get("transaction_id").toString());
		wxPayInfo.setCallbackTime(new Date());

		wxPayInfoService.updateWhenPaySuccess(wxPayInfo);


		returnMap.put("return_code","SUCCESS");
		returnMap.put("return_msg","处理成功");
		return MessageUtil.messageToXML(returnMap);
	}


}
