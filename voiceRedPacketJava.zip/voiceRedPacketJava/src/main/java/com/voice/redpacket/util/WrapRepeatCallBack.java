package com.voice.redpacket.util;

/**
 * 封装重复代码回调类
 * Created by ZhaoYuJie on 2017/12/14.
 */
public interface WrapRepeatCallBack<T> {
    T callBack() throws Exception;
}
