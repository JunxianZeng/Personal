package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.WindowConstants;

import db.BaseDAO;
import vo.AccountVo;

public class LoginUI extends JFrame implements MouseListener,ActionListener,ItemListener,MouseMotionListener{
	JLabel lblMin,lblClose,lblHead,lblReg,lblForgetPwd;
	JButton btnLogin;
	JPasswordField txtPassword;
	JComboBox cbQQcode;
	JCheckBox cbpwd,cbAutoLogin;
	HashMap<Integer, AccountVo> user =null;
	JLabel bg;
	public LoginUI() {
		//���ر�����
		setUndecorated(true);
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Image img = toolkit.getImage("head/touxiang.png");
		setIconImage(img);
		bg = new JLabel(new ImageIcon("images/login.jpg"));
		//���Բ���
		bg.setLayout(null);
		bg.addMouseMotionListener(this);
		add(bg);
		lblMin = new JLabel("-");
		lblMin.setForeground(Color.WHITE);
		lblMin.setFont(new Font("����",Font.BOLD,20));
		lblClose = new JLabel("x");
		lblClose.setForeground(Color.WHITE);
		lblClose.setFont(new Font("����",Font.BOLD,18));
		lblMin.setBounds(380, 0, 20, 20);
		lblClose.setBounds(400, 0, 20, 20);
		lblMin.addMouseListener(this);
		lblClose.addMouseListener(this);
		bg.add(lblMin);
		bg.add(lblClose);
		lblHead = new JLabel(new ImageIcon("head/touxiang.png"));
		lblReg = new JLabel("        ");
		lblForgetPwd = new JLabel("      ");
		cbQQcode = new JComboBox();
		txtPassword = new JPasswordField();
		btnLogin = new JButton("��¼");
		cbpwd = new JCheckBox("��ס����");
		cbAutoLogin = new JCheckBox("�Զ���¼");
		
		cbQQcode.setBounds(130, 185, 194, 30);
		//�����������п���ֱ����������
		cbQQcode.setEditable(true);
		cbQQcode.setToolTipText("�˺�");
		txtPassword.setBounds(130, 215, 195, 30);
		txtPassword.setToolTipText("����");
		lblReg.setBounds(335, 185, 80, 30);
//		lblReg.setFont(new Font("����",Font.PLAIN,14));
//		lblReg.setForeground(Color.BLUE);
		lblForgetPwd.setBounds(335, 215, 80, 30);
		lblHead.setBounds(70, 185, 60, 60);
		btnLogin.setBounds(130, 278, 195, 30);
		btnLogin.setBackground(Color.LIGHT_GRAY);
		cbpwd.setBounds(127, 243, 80, 30);
		cbAutoLogin.setBounds(254, 243, 80, 30);
		//͸������
		cbpwd.setOpaque(false);
		cbAutoLogin.setOpaque(false);
		btnLogin.setOpaque(false);
		
		bg.add(cbQQcode);
		bg.add(txtPassword);
		bg.add(lblReg);
		bg.add(lblForgetPwd);
		bg.add(lblHead);
		bg.add(btnLogin);
		bg.add(cbpwd);
		bg.add(cbAutoLogin);
		
		lblReg.addMouseListener(this);
		lblForgetPwd.addMouseListener(this);
		cbpwd.addActionListener(this);
		cbAutoLogin.addActionListener(this);
		btnLogin.addActionListener(this);
		cbQQcode.addItemListener(this);
		//��ȡ�ļ�����
		readFile();
		
		
		setSize(427, 321);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new LoginUI();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==lblMin){
		this.setState(WindowConstants.HIDE_ON_CLOSE);
			
		}else if(e.getSource()==lblClose){
			System.exit(0);
		}else if(e.getSource()==lblReg){
//			JOptionPane.showMessageDialog(this, "ע���˺�");
			new RegUI();
		}else if(e.getSource()==lblForgetPwd){
			JOptionPane.showMessageDialog(this, "�һ�����");
		}
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		x=this.getX();
		y=this.getY();
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==btnLogin){
			String qqcode="";
			String pwd = txtPassword.getText().trim();
			if(cbQQcode.getSelectedItem() == null){
				JOptionPane.showMessageDialog(this, "������QQ����");
				return;
			}
			if(pwd.equals("")){
				JOptionPane.showMessageDialog(this, "�������¼����");
				return;
			}
			qqcode = cbQQcode.getSelectedItem().toString();
			
			AccountVo account = new AccountVo();
			account.setQqCode(Integer.parseInt(qqcode));
			account.setPassword(pwd);
			account = new BaseDAO().login(account);
			if(account==null){
				JOptionPane.showMessageDialog(this, "��¼ʧ�ܣ��û������������!");
				return;
			}else{
//				JOptionPane.showMessageDialog(this, "��¼�ɹ�");
				//�����¼�ɹ���QQ���뵽�ļ���
				save(account);
				
				//��¼�ɹ��󣬹رյ�ǰ���ڣ�
				dispose();
				//��ʾ������,ͬʱ�ѵ�¼�ɹ��ĸ�����Ϣaccount���󣬴��ݵ�������
				new MainUI(account);
			}
			
			
		}else if(e.getSource()==cbpwd){
			JOptionPane.showMessageDialog(this, "��ס����");
		}
		
	}
	//�����¼�ɹ���QQ���뵽�ļ���
	public void save(AccountVo account){
		HashMap<Integer, AccountVo> user =null;
		File file = new File("account.dat");
		try {
			if(!file.exists()){//��һ��ʹ��QQ
					file.createNewFile();
					user = new HashMap<Integer, AccountVo>();
			}else{
				FileInputStream fis = new FileInputStream(file);
				ObjectInputStream ois = new ObjectInputStream(fis);
				//��ȡ�ļ�����
				user = (HashMap<Integer, AccountVo>)ois.readObject();
				fis.close();
				ois.close();
			}
			//�µ�¼���û���Ϣ���浽hashMap��
			user.put(account.getQqCode(), account);
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("account.dat"));
			oos.writeObject(user);
			oos.flush();
			oos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//��ȡ�ļ�����
	public void readFile(){
		try{
			File file = new File("account.dat");
			//�ļ������ھͽ���
			if(!file.exists()){
				return;
			}
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			//��Ա���������Ǿֲ�����
			user = (HashMap<Integer, AccountVo>)ois.readObject();
			Set<Integer> set = user.keySet();
			Iterator<Integer> it = set.iterator();
			while(it.hasNext()){
				cbQQcode.addItem(it.next());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		if(e.getSource()==cbQQcode){
			if(!cbQQcode.getSelectedItem().toString().equals("") && user!=null){
				int qqcode = Integer.parseInt(cbQQcode.getSelectedItem().toString());
				AccountVo account = user.get(qqcode);
				if(account!=null){
					txtPassword.setText(account.getPassword());
					lblHead.setIcon(new ImageIcon(account.getHeadImg()));
				}
			}
		}
	}
	int x,y;
	@Override
	public void mouseDragged(MouseEvent e) {
//		this.setLocation(e.getX()+x, e.getY()+y);
//		x=this.getX();
//		y=this.getY();
		Point p = this.getLocationOnScreen();
		this.setLocation(e.getX()+p.x, e.getY()+p.y);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		
	}
}
