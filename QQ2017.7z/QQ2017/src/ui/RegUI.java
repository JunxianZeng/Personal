package ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

import db.BaseDAO;
import vo.AccountVo;

public class RegUI extends JFrame implements ActionListener{
	private JLabel lblQQcode,lblnickName,lblPassword,lblcfgPwd,lblAge;
	private JLabel lblSex,lblNation,lblStar,lblBlood,lblIpAddr,lblPort;
	private JLabel lblRemark,lblHobit,lblHeadImg;
	private JTextField txtQQcode,txtNickName,txtAge,txtIpAddr,txtPort,txtHobit;
	private JPasswordField txtPassword,txtCfgPwd;
	private JRadioButton rbMale,rbRemale;
	private JComboBox cbNation,cbStar,cbBlood,cbHeadImg;
	private JTextArea taRemark;
	private ButtonGroup bg;
	private JLabel lblBg;
	private JButton btnSave,btnClose;
	private String sNation[]={
			"����","����","׳��","��ɽ��","����","����",
			"����","����","������","����"
	};
	private String sStar[]={
			"˫����","��ţ��","Ħ����","��Ы��","��Ů��","ʨ����","������",
			"ˮƿ��","������","�����","��з��","˫����",
	};
	private String sBlood[]={"A","B","O","AB"};
	private String sHeadImg[] = {
			"head/0.png","head/1.png","head/2.png",
			"head/3.png","head/4.png","head/5.png",
			"head/6.png","head/7.png","head/8.png",
			"head/9.png","head/10.png"
	};
	private ImageIcon[] headIcon = {
			new ImageIcon(sHeadImg[0]),
			new ImageIcon(sHeadImg[1]),
			new ImageIcon(sHeadImg[2]),
			new ImageIcon(sHeadImg[3]),
			new ImageIcon(sHeadImg[4]),
			new ImageIcon(sHeadImg[5]),
			new ImageIcon(sHeadImg[6]),
			new ImageIcon(sHeadImg[7]),
			new ImageIcon(sHeadImg[8]),
			new ImageIcon(sHeadImg[9]),
			new ImageIcon(sHeadImg[10])
	};
	public RegUI(){
		super("QQ�û�ע��");
		setIconImage(new ImageIcon("images/tubiao.jpg").getImage());
		lblBg = new JLabel(new ImageIcon("images/bgreg.jpg"));
		add(lblBg);
		lblBg.setLayout(null);
		JLabel title = new JLabel("�û�ע��",SwingConstants.CENTER);
		title.setFont(new Font("����",Font.BOLD,36));
		title.setForeground(Color.RED);
		title.setBounds(0,30,160,40);
		lblBg.add(title);
		lblQQcode = new JLabel("QQ����:",SwingConstants.RIGHT);
		lblnickName = new JLabel("�ǳ�:",SwingConstants.RIGHT);
		lblHeadImg = new JLabel("ͷ��:",SwingConstants.RIGHT);
		lblPassword = new JLabel("��¼����:",SwingConstants.RIGHT);
		lblcfgPwd = new JLabel("ȷ������:",SwingConstants.RIGHT);
		lblAge = new JLabel("����:",SwingConstants.RIGHT);
		lblSex = new JLabel("�Ա�:",SwingConstants.RIGHT);
		lblNation = new JLabel("����:",SwingConstants.RIGHT);
		lblStar = new JLabel("����:",SwingConstants.RIGHT);
		lblBlood = new JLabel("Ѫ��:",SwingConstants.RIGHT);
		lblHobit = new JLabel("����:",SwingConstants.RIGHT);
		lblIpAddr = new JLabel("IP��ַ:",SwingConstants.RIGHT);
		lblPort = new JLabel("�˿�:",SwingConstants.RIGHT);
		lblRemark = new JLabel("��ע:",SwingConstants.RIGHT);
		
		txtQQcode = new JTextField(10);
		txtQQcode.setText("ϵͳ�Զ�����");
		txtQQcode.setEditable(false);
		txtNickName = new JTextField(10);
		cbHeadImg = new JComboBox(headIcon);
		txtPassword = new JPasswordField(10);
		txtPassword.setEchoChar('@');
		txtCfgPwd = new JPasswordField(10);
		txtCfgPwd.setEchoChar('@');
		txtAge = new JTextField(5);
		rbMale = new JRadioButton("��",true);
		rbRemale = new JRadioButton("Ů");
		bg = new ButtonGroup();
		bg.add(rbMale);
		bg.add(rbRemale);
		cbNation = new JComboBox(sNation);
		cbStar = new JComboBox(sStar);
		cbBlood = new JComboBox(sBlood);
		txtHobit = new JTextField(20);
		InetAddress addr=null;
		try {
			addr = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		txtIpAddr = new JTextField(addr.getHostAddress());
		txtPort = new JTextField(5);
		txtPort.setEditable(false);
		txtPort.setText("ϵͳ�Զ�����");
		taRemark  = new JTextArea(3,80);
		
		lblQQcode.setBounds(0, 100, 100, 20);
		txtQQcode.setBounds(100, 100, 150, 20);
		lblnickName.setBounds(0, 140, 100, 20);
		txtNickName.setBounds(100, 140, 150, 20);
		//����͸��
//		txtNickName.setOpaque(false);
		
		lblHeadImg.setBounds(280, 100, 80, 60);
		cbHeadImg.setBounds(360, 100, 80, 60);
		
		lblPassword.setBounds(0, 180, 100, 20);
		txtPassword.setBounds(100, 180, 150, 20);
		lblcfgPwd.setBounds(280, 180, 80, 20);
		txtCfgPwd.setBounds(360, 180, 150, 20);

		lblAge.setBounds(0, 220, 100, 20);
		txtAge.setBounds(100, 220, 150, 20);
		lblSex.setBounds(280, 220, 80, 20);
		rbMale.setBounds(360, 220, 40, 20);
		rbMale.setOpaque(false);
		rbRemale.setBounds(400, 220, 40, 20);
		rbRemale.setOpaque(false);
		
		lblNation.setBounds(0, 260, 100, 20);
		cbNation.setBounds(100, 260, 150, 20);
		lblStar.setBounds(280, 260, 80, 20);
		cbStar.setBounds(360, 260, 150, 20);
		
		lblBlood.setBounds(0, 300, 100, 20);
		cbBlood.setBounds(100, 300, 150, 20);
		lblHobit.setBounds(0, 340, 100, 20);
		txtHobit.setBounds(100, 340, 410, 20);

		lblIpAddr.setBounds(0, 380, 100, 20);
		txtIpAddr.setBounds(100, 380, 150, 20);
		lblPort.setBounds(280, 380, 80, 20);
		txtPort.setBounds(360, 380, 150, 20);
		
		lblRemark.setBounds(0, 420, 100, 20);
		taRemark.setBounds(100, 420, 410, 80);
		
		lblBg.add(lblQQcode);
		lblBg.add(txtQQcode);
		lblBg.add(lblnickName);
		lblBg.add(txtNickName);
		lblBg.add(lblHeadImg);
		lblBg.add(cbHeadImg);
		lblBg.add(lblPassword);
		lblBg.add(txtPassword);
		lblBg.add(lblcfgPwd);
		lblBg.add(txtCfgPwd);
		lblBg.add(lblAge);
		lblBg.add(txtAge);
		lblBg.add(lblSex);
		lblBg.add(rbMale);
		lblBg.add(rbRemale);
		lblBg.add(lblNation);
		lblBg.add(cbNation);
		lblBg.add(lblStar);
		lblBg.add(cbStar);
		lblBg.add(lblBlood);
		lblBg.add(cbBlood);
		lblBg.add(lblHobit);
		lblBg.add(txtHobit);
		lblBg.add(lblIpAddr);
		lblBg.add(txtIpAddr);
		lblBg.add(lblPort);
		lblBg.add(txtPort);
		lblBg.add(lblRemark);
		lblBg.add(taRemark);
		btnSave = new JButton("����(S)");
		btnSave.setMnemonic('S');
		btnClose = new JButton("�ر�(X)");
		btnClose.setMnemonic('X');
		
		btnSave.setBounds(180, 520, 100, 40);
		btnClose.setBounds(350, 520, 100, 40);
		lblBg.add(btnSave);
		lblBg.add(btnClose);
		btnSave.addActionListener(this);
		btnClose.addActionListener(this);
		//���ر�����
		setUndecorated(true);
		setResizable(false);
		setSize(550, 580);
		setVisible(true);
		setLocationRelativeTo(null);
		//�رմ��ڣ����˳�Ӧ�ó���
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}

	public static void main(String[] args) {
		new RegUI();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()== btnSave){
			String nickname = txtNickName.getText().trim();
			if(nickname.equals("")){
				JOptionPane.showMessageDialog(this, "�������ǳ�");
				return;
			}
			String pass= txtPassword.getText().trim();
			String cfgpass= txtCfgPwd.getText().trim();
			if(pass.equals("")){
				JOptionPane.showMessageDialog(this, "�������¼����");
				return;
			}
			if(!pass.equals(cfgpass)){
				JOptionPane.showMessageDialog(this, "��¼������ȷ�����벻һ��");
				return;
			}
			int age = 0;
			String sage = txtAge.getText().trim();
			if(sage.equals("")){
				JOptionPane.showMessageDialog(this, "����������");
				txtAge.setText("0");
				return;
			}
			try{
				age = Integer.parseInt(sage);
			}catch(Exception ex){
				JOptionPane.showMessageDialog(this, "������0~150֮�������");
				return;
			}
			if(age<0 || age>150){
				JOptionPane.showMessageDialog(this, "������0~150֮�������");
				return;
			}
			AccountVo account = new AccountVo();
			account.setNickName(nickname);
			account.setHeadImg(sHeadImg[cbHeadImg.getSelectedIndex()]);
			account.setPassword(pass);
			account.setAge(age);
			if(rbMale.isSelected()){
				account.setSex("��");
			}else{
				account.setSex("Ů");
			}
			account.setNation(sNation[cbNation.getSelectedIndex()]);
			account.setStar(sStar[cbStar.getSelectedIndex()]);
			account.setBlood(sBlood[cbBlood.getSelectedIndex()]);
			account.setHobit(txtHobit.getText().trim());
			account.setIpAddr(txtIpAddr.getText().trim());
			account.setRemark(taRemark.getText().trim());
			BaseDAO baseDAO = new BaseDAO();
			//������Ϣ�����ݿ��е�account��
			account=baseDAO.saveAccount(account);
			//��txtQQcode�ı���ֵ
			txtQQcode.setText(account.getQqCode() +"");
			txtPort.setText("0");
			JOptionPane.showMessageDialog(this, "��ϲ��ע��ɹ�������QQ�����ǣ�"+account.getQqCode());
		}else if(e.getSource()==btnClose){
			dispose();
		}
	}
	
}
