package ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.table.AbstractTableModel;
import base.Cmd;
import base.SendCmd;
import base.SendMsg;
import db.BaseDAO;
import vo.AccountVo;

public class FindUI extends JFrame implements ActionListener,MouseListener{

	JLabel lblQQcode,lblNickName,lblAge;
	JTextField txtQQcode,txtNickName,txtAge;
	JComboBox cbSex,cbStatus;
	JTable dataTable;
	JButton btnFind,btnAdd,btnClose;
	AccountVo myInfo;
	Vector<String> vHead;
	Vector vData;
	public FindUI() {
		init();
	}
	public FindUI(AccountVo acc) {
		this.myInfo = acc;
		init();
	}
	String sSex[] = {"��ѡ��","��","Ů"};
	String sStatus[]={"��ѡ��","����","����","æµ","����"};
	BaseDAO baseDAO = new BaseDAO();
	public void init(){
		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		lblQQcode = new JLabel("QQ����");
		lblNickName = new JLabel("�ǳ�");
		lblAge = new JLabel("����");
		txtQQcode = new JTextField(8);
		txtNickName = new JTextField(8);
		txtAge = new JTextField(5);
		cbSex = new JComboBox(sSex);
		cbStatus = new JComboBox(sStatus);
		btnFind = new JButton("����");
		topPanel.add(lblQQcode);
		topPanel.add(txtQQcode);
		topPanel.add(lblNickName);
		topPanel.add(txtNickName);
		topPanel.add(lblAge);
		topPanel.add(txtAge);
		topPanel.add(cbSex);
		topPanel.add(cbStatus);
		topPanel.add(btnFind);
		add(topPanel,BorderLayout.NORTH);
		String[] columnNames = {"ͷ��", "QQ����", "�ǳ�", "����", "�Ա�","Ѫ��","����","����","����","״̬","��ע"};
		vHead = new Vector<String>();
		for(int i=0;i<columnNames.length;i++){
			vHead.addElement(columnNames[i]);
		}
		String sql = "select headimg,qqcode,nickname,age,sex,blood,star,nation,hobit,onlinestatus,remark from account";
		vData = baseDAO.findFriend(sql);
		dataTable = new JTable(new MyTableModel(vHead,vData));
		dataTable.addMouseListener(this);
		dataTable.setRowHeight(60);
		add(new JScrollPane(dataTable));
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		btnAdd = new JButton("���Ӻ���");
		btnClose = new JButton("�رմ���");
		bottomPanel.add(btnAdd);
		bottomPanel.add(btnClose);
		add(bottomPanel,BorderLayout.SOUTH);
		btnFind.addActionListener(this);
		btnAdd.addActionListener(this);
		btnClose.addActionListener(this);
		setSize(800, 500);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}
	public static void main(String[] args) {
		new FindUI();
	}
    //�ڲ���ʵ�ֳ����TableModel������д��Ҫ�ķ���
    class MyTableModel extends AbstractTableModel {
    	Vector<String> vHead;
    	Vector data;
        public MyTableModel(Vector<String> vHead,Vector data) {
        	this.vHead = vHead;
        	this.data = data;
        }
        //�õ������г���
        @Override
		public int getColumnCount() {
            return vHead.size();
        }
        //�õ���������
        @Override
		public int getRowCount() {
            return data.size();
        }
        //�õ���������
        @Override
		public String getColumnName(int col) {
//            System.out.println(" ���е�����Ϊ��" + vHead.get(col));
            return vHead.get(col);
        }
        //�õ�ָ����Ԫ��ֵ
        @Override
		public Object getValueAt(int row, int col) {
        	Vector rowData = (Vector)vData.get(row);
			if(col==0){//��ʾͷ��
				return new ImageIcon(rowData.get(col).toString());
			}else{
				return rowData.get(col);
			}
        }
        //����ָ���е���������
        @Override
		public Class<?> getColumnClass(int c) {
        	if(c==0){//��ʾͷ��
				return ImageIcon.class;
			}else{
				return super.getColumnClass(c);
			}
        }
        //���õ�Ԫ���Ƿ���޸�
        @Override
		public boolean isCellEditable(int row, int col) {
            return false;
        }

        //���õ�Ԫ���ֵ
        @Override
		public void setValueAt(Object value, int row, int col) {
        	Vector rowData = (Vector)vData.get(row);
        	rowData.set(col, value);
            fireTableCellUpdated(row, col);
        }
    }
	@Override
	public void actionPerformed(ActionEvent e) {

		if(e.getSource()==btnFind){
			String sql = "select headimg,qqcode,nickname,age,sex,blood,star,nation,hobit,onlinestatus,remark from account";
			sql += " where 1=1 ";
			String qqcode = txtQQcode.getText().trim();
			String nickname = txtNickName.getText().trim();
			String age = txtAge.getText().trim();
			if(!qqcode.equals("")){
				sql += " and qqcode=" + qqcode ;
			}
			if(!nickname.equals("")){
				sql += " and nickname like '%"+nickname + "%'";
			}
			if(!age.equals("")){
				sql += " and age="+age;
			}
			String sex = sSex[cbSex.getSelectedIndex()];
			String status = sStatus[cbStatus.getSelectedIndex()];
			if(!sex.equals("��ѡ��")){
				sql += " and sex='"+sex + "'";
			}
			if(!status.equals("��ѡ��")){
				sql += " and onlinestatus='"+status + "'";
			}
			sql += " order by age";
			vData = baseDAO.findFriend(sql);
			dataTable.setModel(new MyTableModel(vHead,vData));

		}else if(e.getSource()==btnAdd){
			int index = dataTable.getSelectedRow();
			if(index>=0){
				Vector row = (Vector)vData.get(index);
				//��ȡQQ����
				int qqcode = Integer.parseInt(row.get(1).toString());
				AccountVo friendInfo = baseDAO.getSelectedFriend(qqcode);
				String str = "�Ƿ����ӡ�"+friendInfo.getNickName()+"��Ϊ���ĺ��ѣ�";
				if(JOptionPane.showConfirmDialog(this, str,"���Ӻ���",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
					
					SendMsg msg = new SendMsg();
					msg.cmd = Cmd.CMD_ADDFRI;
					msg.myInfo = myInfo;
					msg.friendInfo = friendInfo;
					SendCmd.send(msg);
				}
			}
		}else if(e.getSource()==btnClose){
			dispose();
		}
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==dataTable){
			int index = dataTable.getSelectedRow();
			if(index>=0){
				if(e.getClickCount()==2){
					Vector row = (Vector)vData.get(index);
					//��ȡQQ����
					int qqcode = Integer.parseInt(row.get(1).toString());
					if(qqcode==myInfo.getQqCode()){
						JOptionPane.showMessageDialog(this, "���������Լ�Ϊ���ѣ�");
						return;
					}
					//�ж��Ƿ��Ѿ�Ϊ����
					if(baseDAO.isFriend(myInfo.getQqCode(), qqcode)){
						JOptionPane.showMessageDialog(this, "�����Ѿ��Ǻ��ѣ�");
						return;
					}

					AccountVo friendInfo = baseDAO.getSelectedFriend(qqcode);
					String str = "�Ƿ����ӡ�"+friendInfo.getNickName()+"��Ϊ���ĺ��ѣ�";
					if(JOptionPane.showConfirmDialog(this, str,"���Ӻ���",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
						SendMsg msg = new SendMsg();
						msg.cmd = Cmd.CMD_ADDFRI;
						msg.myInfo = myInfo;
						msg.friendInfo = friendInfo;
						SendCmd.send(msg);
					}
				}
			}
		}
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	
	
}
