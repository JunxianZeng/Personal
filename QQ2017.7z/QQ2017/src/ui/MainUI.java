package ui;

import java.awt.AWTException;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.Hashtable;
import java.util.Vector;

import javax.swing.AbstractListModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.text.BadLocationException;
import base.Cmd;
import base.SendCmd;
import base.SendMsg;
import db.BaseDAO;
import vo.AccountVo;

public class MainUI extends JFrame implements ActionListener,MouseListener,ItemListener,WindowListener{
	JLabel bgImg,lblMyInfo;
	JTabbedPane tabPanel;
	JList lstFriend,lstmate,lstFamliy,lstHmd;
	JButton btnFind,btnChangebj;
	//�����˵�
	JPopupMenu popMenu;
	JMenuItem miChat,miFamily,miFriend,miMate,miHmd,miLookInfo,miDel;
	//����״̬
	JComboBox cbState;
	//�����¼�ɹ���ĸ�����Ϣ
	AccountVo myInfo,friendInfo;
	//�������еĺ�����Ϣ�����ѣ����ˣ�ͬѧ����������
	Vector<AccountVo> vAllInfo,vFriend,vFamily,vMate,vHmd;
	BaseDAO baseDAO = new BaseDAO();
	Hashtable<Integer, ChatUI> chatWin = new Hashtable<Integer, ChatUI>();
	//���̵�ͼ��
	TrayIcon trayIcon;
	//���̶�Ӧ�Ĳ˵�
	PopupMenu popTray;
	MenuItem miOpen,miExit,miOnline,miLevel,miBuys;
	public MainUI() {
		
	}
	public MainUI(AccountVo myInfo) {
		this.myInfo = myInfo;
		//���������¼�
		addWindowListener(this);
		//���ô���ͼ��
		setIconImage(new ImageIcon(myInfo.getHeadImg()).getImage());
//		setUndecorated(true);
		setResizable(false);
		bgImg = new JLabel(new ImageIcon("images/bgmain3.jpg"));
		bgImg.setLayout(new BorderLayout());
		//���ñ���͸��
		bgImg.setOpaque(false);
		add(bgImg);
		vAllInfo = new Vector<AccountVo>();
		vFriend = new Vector<AccountVo>();
		vFamily = new Vector<AccountVo>();
		vMate = new Vector<AccountVo>();
		vHmd = new Vector<AccountVo>();
		lstFriend = new JList();
		lstmate = new JList();
		lstFamliy = new JList();
		lstHmd = new JList();
		lstFriend.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//����͸��
		lstFriend.setOpaque(false);
		lstmate.setOpaque(false);
		lstFamliy.setOpaque(false);
		lstHmd.setOpaque(false);
		lstFriend.addMouseListener(this);
		lstmate.addMouseListener(this);
		lstFamliy.addMouseListener(this);
		lstHmd.addMouseListener(this);
		//����TabbedPaneΪ͸������
		UIManager.put("TabbedPane.contentOpaque", false);
		tabPanel = new JTabbedPane();
		tabPanel.setOpaque(false);
		//���ӱ�ǩҳ
		tabPanel.addTab("����", lstFriend);
		tabPanel.addTab("ͬѧ", lstmate);
		tabPanel.addTab("����Ⱥ", lstFamliy);
		tabPanel.addTab("������", lstHmd);
		bgImg.add(tabPanel);
		refresh();

		//���ø���ͷ��
		ImageIcon icon = new ImageIcon(myInfo.getHeadImg());
		String nickname = myInfo.getNickName()+"("+myInfo.getQqCode()+")��"+myInfo.getRemark()+"��";
		lblMyInfo = new JLabel(nickname,icon,SwingConstants.LEFT);
		lblMyInfo.setOpaque(false);
		bgImg.add(lblMyInfo,BorderLayout.NORTH);
		lblMyInfo.addMouseListener(this);
		//������Ű�ť
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		bottomPanel.setOpaque(false);
		btnFind = new JButton("����");
		btnChangebj = new JButton("����");
		btnFind.addActionListener(this);
		btnChangebj.addActionListener(this);
		//״̬
		cbState = new JComboBox(Cmd.STATUS);
		cbState.addItemListener(this);
		//ɾ������״̬
		cbState.removeItemAt(1);
		bottomPanel.add(btnFind);
		bottomPanel.add(btnChangebj);
		bottomPanel.add(cbState);
		
		bgImg.add(bottomPanel,BorderLayout.SOUTH);
		createMenu();
		//�����߳�
		new ReceiveThread().start();
		//���͵�¼�㲥
		SendCmd.sendAll(vAllInfo, myInfo, Cmd.CMD_ONLINE);
		//�������̲˵�
		createTrayMenu();
		//��������ͼ��
		setTrayIcon();
		setSize(300, 700);
		setVisible(true);
		setLocation(1050, 50);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
	//�����˵�
	public void createMenu(){
		miChat = new JMenuItem("����");
		miFamily = new JMenuItem("�Ƶ�������");
		miFriend = new JMenuItem("�Ƶ�������");
		miMate = new JMenuItem("�Ƶ�ͬѧ��");
		miHmd = new JMenuItem("�Ƶ�������");
		miLookInfo = new JMenuItem("�鿴������Ϣ");
		miDel = new JMenuItem("ɾ����������");
		//�����¼�
		miChat.addActionListener(this);
		miFamily.addActionListener(this);
		miFriend.addActionListener(this);
		miMate.addActionListener(this);
		miHmd.addActionListener(this);
		miLookInfo.addActionListener(this);
		miDel.addActionListener(this);
		popMenu = new JPopupMenu();
		popMenu.add(miChat);
		popMenu.add(miFamily);
		popMenu.add(miFriend);
		popMenu.add(miMate);
		popMenu.add(miHmd);
		popMenu.add(miLookInfo);
		popMenu.add(miDel);
	}
	//�Ѻ�����Ϣ�ֱ�ŵ���Ӧ��Vector��
	public void refresh(){
		//��ȡ���еĺ�����Ϣ�����ѣ����ˣ�ͬѧ����������
		vAllInfo = baseDAO.getMyFriend(myInfo.getQqCode());
//		"ͬѧ","����","����","������"
		//���Vector��ֵ
		vMate.clear();
		vFriend.clear();
		vFamily.clear();
		vHmd.clear();
		for (AccountVo acc : vAllInfo) {
			String groupName = acc.getGroupName();
			if(groupName.equals(Cmd.GROUPNAME[0])){
				vMate.add(acc);
			}else if(groupName.equals(Cmd.GROUPNAME[1])){
				vFriend.add(acc);
			}else if(groupName.equals(Cmd.GROUPNAME[2])){
				vFamily.add(acc);
			}else if(groupName.equals(Cmd.GROUPNAME[3])){
				vHmd.add(acc);
			}
		}
		//��ʼ��List�������ʾ
		lstFriend.setModel(new DataModel(vFriend));
		lstmate.setModel(new DataModel(vMate));
		lstFamliy.setModel(new DataModel(vFamily));
		lstHmd.setModel(new DataModel(vHmd));
		lstFriend.setCellRenderer(new MyHeadImg(vFriend));
		lstmate.setCellRenderer(new MyHeadImg(vMate));
		lstFamliy.setCellRenderer(new MyHeadImg(vFamily));
		lstHmd.setCellRenderer(new MyHeadImg(vHmd));
	}
	public static void main(String[] args) {
		new MainUI();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		//��������ͼƬ
		if(e.getSource()==btnChangebj){
			JFileChooser dlg = new JFileChooser();
			//���ļ��Ի���
			dlg.setDialogType(JFileChooser.OPEN_DIALOG);
			dlg.setFileSelectionMode(JFileChooser.FILES_ONLY);
            //���öԻ������
			dlg.setDialogTitle("����Ƥ��");
            if (dlg.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            	File file = dlg.getSelectedFile();
            	String path = file.getPath();
            	bgImg.setIcon(new ImageIcon(path));
            }
		}else if(e.getSource()==miLookInfo){
//			friendInfo = vFriend.get(lstFriend.getSelectedIndex());
			new LookInfoUI(friendInfo);
		}else if(e.getSource()== miFriend){
			baseDAO.moveGroup(myInfo.getQqCode(), friendInfo.getQqCode(), Cmd.GROUPNAME[1]);
			refresh();
		}else if(e.getSource()== miFamily){
			baseDAO.moveGroup(myInfo.getQqCode(), friendInfo.getQqCode(), Cmd.GROUPNAME[2]);
			refresh();
			
		}else if(e.getSource()== miMate){
			baseDAO.moveGroup(myInfo.getQqCode(), friendInfo.getQqCode(), Cmd.GROUPNAME[0]);
			refresh();
		}else if(e.getSource()== miHmd){
			baseDAO.moveGroup(myInfo.getQqCode(), friendInfo.getQqCode(), Cmd.GROUPNAME[3]);
			refresh();
		}else if(e.getSource()==btnFind){
			new FindUI(myInfo);
		}else if(e.getSource()==miChat){
			openChat();
		}else if(e.getSource()==miOpen){
			//��ȡϵͳ����
			SystemTray tray = SystemTray.getSystemTray();
			//ɾ��ͼ��
			tray.remove(trayIcon);
			//��ʾ������
			MainUI.this.setVisible(true);
			//�ָ�������״̬
			MainUI.this.setState(Frame.NORMAL);
		}else if(e.getSource()==miExit){
			baseDAO.changeStatus(myInfo.getQqCode(), Cmd.STATUS[1]);
			myInfo.setOnlinestatus(Cmd.STATUS[1]);
			SendCmd.sendAll(vAllInfo, myInfo, Cmd.CMD_OFFLINE);
			System.exit(0);
		}else if(e.getSource()==miBuys){
			String status = Cmd.STATUS[2];
			 changeState(status);
			 baseDAO.changeStatus(myInfo.getQqCode(), status);
			 SendCmd.sendAll(vAllInfo, myInfo, Cmd.CMD_CHANGESTATE);
		}
		else if(e.getSource()==miLevel){
			String status = Cmd.STATUS[3];
			 changeState(status);
			 baseDAO.changeStatus(myInfo.getQqCode(), status);
			 SendCmd.sendAll(vAllInfo, myInfo, Cmd.CMD_CHANGESTATE);
		}else if(e.getSource()==miOnline){
			String status = Cmd.STATUS[0];
			 changeState(status);
			 baseDAO.changeStatus(myInfo.getQqCode(), status);
			 SendCmd.sendAll(vAllInfo, myInfo, Cmd.CMD_CHANGESTATE);
		}else if(e.getSource()==miDel){//ɾ������
			baseDAO.delFriend(myInfo.getQqCode(), friendInfo.getQqCode());
			refresh();
			SendMsg msg = new SendMsg();
			msg.cmd = Cmd.CMD_DELFRIEND;
			msg.myInfo=myInfo;
			msg.friendInfo = friendInfo;
			SendCmd.send(msg);
		}
	}
	//��ʾ�ı���Ϣ
	class DataModel extends AbstractListModel {
		Vector<AccountVo> data;
		public DataModel() {}
		public DataModel(Vector<AccountVo> data) {
			this.data = data;
		}
	    //ϵͳ�Զ����У��±��0��ʼ����
	    @Override
		public Object getElementAt(int index) {
	    	AccountVo info = data.get(index);
	    	return info.getNickName()+"("+info.getQqCode()+")��"+info.getRemark()+"��";
	    }

	    @Override
		public int getSize() {
	        return data.size();
	    }
	    
	}
	// ��ȡ����ͷ��
	class MyHeadImg extends DefaultListCellRenderer {
		Vector<AccountVo> datas;
		public MyHeadImg(Vector<AccountVo> datas) {
			this.datas = datas;
		}
		@Override
		public Component getListCellRendererComponent(JList list, Object value,
				int index, boolean isSelected, boolean cellHasFocus) {
			Component c = super.getListCellRendererComponent(list, value,
					index, isSelected, cellHasFocus);
			if (index >= 0 && index < datas.size()) {
				AccountVo user =  datas.get(index);
				String status = user.getOnlinestatus();
				String headImg = user.getHeadImg();
//				STATUS={"����","����","æµ","����"};
				String filename = "";
				if(status.equals(Cmd.STATUS[0])){
					filename = headImg;
				}else if(status.equals(Cmd.STATUS[1])){
					int pos = headImg.indexOf('.');
					String pre = headImg.substring(0,pos);
					String fix = headImg.substring(pos,headImg.length());
					filename = pre + "_h"+fix;
				}else if(status.equals(Cmd.STATUS[2])){
					int pos = headImg.indexOf('.');
					String pre = headImg.substring(0,pos);
					String fix = headImg.substring(pos,headImg.length());
					filename = pre + "_l"+fix;
				}else if(status.equals(Cmd.STATUS[3])){
					int pos = headImg.indexOf('.');
					String pre = headImg.substring(0,pos);
					String fix = headImg.substring(pos,headImg.length());
					filename = pre + "_w"+fix;
				}
				// ���б��к���״̬����ͷ��
				System.out.println(filename);
				setIcon(new ImageIcon(filename));
				//�����ı�����
				setText(user.getNickName()+"("+user.getQqCode()+")��"+user.getRemark()+"��");
				System.out.println(user.getHeadImg());
			}
			// ����������ɫ
			if (isSelected) {
				setBackground(list.getSelectionBackground());
				setForeground(list.getSelectionForeground());
			} else {
				setBackground(list.getBackground());
				setForeground(list.getForeground());
			}
			//������Ч
			setEnabled(list.isEnabled());
			//����Ĭ������
			setFont(list.getFont());
//			����͸��
			setOpaque(false);
			return this;
		}
	}
	//�����촰��
	public ChatUI openChat(){
		//��Hashtable�л�ȡ������������Ĵ�����Ϣ
		ChatUI chat = chatWin.get(friendInfo.getQqCode());
		if(chat==null){
			chat = new ChatUI(myInfo,friendInfo,vFamily);
			chatWin.put(friendInfo.getQqCode(), chat);
		}
		//��ʾ
		chat.show();
		return chat;
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==lblMyInfo){
			if(e.getClickCount()==2){
				new UpdateMyInfoUI(myInfo,this);
			}
		}else if(e.getSource()==lstFriend){
			if(lstFriend.getSelectedIndex()>=0){
				friendInfo = vFriend.get(lstFriend.getSelectedIndex());
			}
			//�Ҽ�
			if(e.getButton()==3){
				if(lstFriend.getSelectedIndex()>=0){
					popMenu.show(lstFriend, e.getX(), e.getY());
				}
			}else if(e.getClickCount()==2){//˫��
				if(lstFriend.getSelectedIndex()>=0){
					openChat();
				}
			}
		}else if(e.getSource()==lstFamliy){
			if(lstFamliy.getSelectedIndex()>=0){
				friendInfo = vFamily.get(lstFamliy.getSelectedIndex());
			}
			if(e.getButton()==3){
				if(lstFamliy.getSelectedIndex()>=0){
					popMenu.show(lstFamliy, e.getX(), e.getY());
				}
			}else if(e.getClickCount()==2){//˫��
				if(lstFamliy.getSelectedIndex()>=0){
					openChat();
				}
			}
		}else if(e.getSource()==lstmate){
			if(lstmate.getSelectedIndex()>=0){
				friendInfo = vMate.get(lstmate.getSelectedIndex());
			}
			if(e.getButton()==3){
				if(lstmate.getSelectedIndex()>=0){
					popMenu.show(lstmate, e.getX(), e.getY());
				}
			}else if(e.getClickCount()==2){//˫��
				if(lstmate.getSelectedIndex()>=0){
					friendInfo = vMate.get(lstmate.getSelectedIndex());
					openChat();
				}
			}
		}else if(e.getSource()==lstHmd){
			if(e.getButton()==3){
				if(lstHmd.getSelectedIndex()>=0){
					friendInfo = vHmd.get(lstHmd.getSelectedIndex());
					popMenu.show(lstHmd, e.getX(), e.getY());
				}
			}
		}
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	//�����ڲ��߳���
	class ReceiveThread extends Thread{
		public ReceiveThread() {
			
		}
		@Override
		public void run() {
			try {
				DatagramSocket socket = new DatagramSocket(myInfo.getPort());
				while(true){
					byte b[] = new byte[1024*512];
					DatagramPacket pack = new DatagramPacket(b,0,b.length);
					//������Ϣ
					socket.receive(pack);
					ByteArrayInputStream bais = new ByteArrayInputStream(pack.getData());
					ObjectInputStream ois = new ObjectInputStream(bais);
					SendMsg msg = (SendMsg)ois.readObject();
					myInfo = msg.friendInfo;
					friendInfo = msg.myInfo;
					switch(msg.cmd){
					case Cmd.CMD_ONLINE: //��¼������)
						refresh();
						new TipUI(friendInfo);
						break;
					case Cmd.CMD_LEVEL:
					case Cmd.CMD_BUYS:
						refresh();
						break;
					case Cmd.CMD_OFFLINE:
						refresh();
						new TipUI(friendInfo);
						break;
					case Cmd.CMD_CHANGESTATE:
						refresh();
						break;
					case Cmd.CMD_SEND: //����������Ϣ
						System.out.println("����������Ϣ....");
						ChatUI chat = openChat();
						try {
								chat.appendView(msg.myInfo.getNickName(), msg.doc);
						} catch (BadLocationException e) {
							e.printStackTrace();
						}
						break;
					case Cmd.CMD_SHAKE:
						chat = openChat();
						chat.shake();
						break;
					case Cmd.CMD_ADDFRI: //���Ӻ���
						String str = "��"+friendInfo.getNickName()+"������������Ϊ���ѣ��Ƿ�ͬ�⣿";
						SendMsg msg2 = new SendMsg();
						if(JOptionPane.showConfirmDialog(null, str,"���Ӻ���",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
							msg2.cmd = Cmd.CMD_ARGEE;
							baseDAO.addFriend(myInfo.getQqCode(), friendInfo.getQqCode());
							refresh();
						}else{
							msg2.cmd = Cmd.CMD_REFUSE;
						}
						msg2.myInfo = myInfo;
						msg2.friendInfo = friendInfo;
						SendCmd.send(msg2);
						break;
					case Cmd.CMD_ARGEE:
						refresh();
						break;
					case Cmd.CMD_REFUSE:
						str = "��"+friendInfo.getNickName()+"���ܾ�����ĺ�������";
						JOptionPane.showMessageDialog(null, str);
						break;
					case Cmd.CMD_DELFRIEND:
						refresh();
						break;
					case Cmd.CMD_FILE:
						str = friendInfo.getNickName()+"������һ����"+msg.fileName+"�ļ������Ƿ���գ�";
						if(JOptionPane.showConfirmDialog(null, "�Ƿ�����ļ�","�����ļ�",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
							JFileChooser chooser = new JFileChooser(" ");
				            chooser.setDialogType(JFileChooser.SAVE_DIALOG);
				            chooser.setDialogTitle("�����ļ�");
				            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
				            	String ext = msg.fileName.substring(msg.fileName.indexOf('.'),msg.fileName.length());
				            	String filename = chooser.getSelectedFile().getAbsolutePath()+ext;
				            	FileOutputStream fos = new FileOutputStream(filename);
				            	fos.write(msg.b);
				            	fos.flush();
				            	fos.close();
				            }
						}
					}
				}
				
				
			} catch (SocketException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			
		}
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
		/*
		 * 1.���Ľ����ͷ��
		 * 2.�����Լ���״̬�����ݿ⣻
		 * 3.֪ͨ���к��ѣ�״̬�ı�
		 * */
		if(e.getSource()==cbState){
			 String status = cbState.getSelectedItem().toString();
			 changeState();
			 baseDAO.changeStatus(myInfo.getQqCode(), status);
			 SendCmd.sendAll(vAllInfo, myInfo, Cmd.CMD_CHANGESTATE);
		}
	}
	//����״̬
	public void changeState(){
		String status = cbState.getSelectedItem().toString();
		String filename=myInfo.getHeadImg();
		String headImg= myInfo.getHeadImg();
		if(status.equals(Cmd.STATUS[0])){
			filename = headImg;
		}else if(status.equals(Cmd.STATUS[2])){
			int pos = headImg.indexOf('.');
			String pre = headImg.substring(0,pos);
			String fix = headImg.substring(pos,headImg.length());
			filename = pre + "_l"+fix;
		}else if(status.equals(Cmd.STATUS[3])){
			int pos = headImg.indexOf('.');
			String pre = headImg.substring(0,pos);
			String fix = headImg.substring(pos,headImg.length());
			filename = pre + "_w"+fix;
		}
		lblMyInfo.setIcon(new ImageIcon(filename));
	}
	//����״̬
	public void changeState(String status){
		String filename=myInfo.getHeadImg();
		String headImg= myInfo.getHeadImg();
		if(status.equals(Cmd.STATUS[0])){
			filename = headImg;
		}else if(status.equals(Cmd.STATUS[2])){
			int pos = headImg.indexOf('.');
			String pre = headImg.substring(0,pos);
			String fix = headImg.substring(pos,headImg.length());
			filename = pre + "_l"+fix;
		}else if(status.equals(Cmd.STATUS[3])){
			int pos = headImg.indexOf('.');
			String pre = headImg.substring(0,pos);
			String fix = headImg.substring(pos,headImg.length());
			filename = pre + "_w"+fix;
		}
		lblMyInfo.setIcon(new ImageIcon(filename));
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	//��������Ҫ�ر�ʱ�ᴥ�����¼�
	@Override
	public void windowClosing(WindowEvent e) {
//		JOptionPane.showMessageDialog(this, "��������Ҫ�ر�");
		//����Ϊ����״̬
		baseDAO.changeStatus(myInfo.getQqCode(), Cmd.STATUS[1]);
		myInfo.setOnlinestatus(Cmd.STATUS[1]);
		SendCmd.sendAll(vAllInfo, myInfo, Cmd.CMD_OFFLINE);
	}
	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
	//������С��ʱ�ᴥ�����¼��������Ҫ����������ͼ��ͱ����ø��¼�
	@Override
	public void windowIconified(WindowEvent e) {
		//��ȡϵͳ����
		SystemTray tray = SystemTray.getSystemTray();
		if(trayIcon!=null){
			tray.remove(trayIcon);
		}
		try {
			tray.add(trayIcon);
			//���ص�ǰ����
			MainUI.this.setVisible(false);
		} catch (AWTException e1) {
			e1.printStackTrace();
		}
	}
	@Override
	public void windowOpened(WindowEvent e) {
		
	}
	//�������̲˵�
	public void createTrayMenu(){
		popTray = new PopupMenu();
		miOpen = new MenuItem("��");
		miExit = new MenuItem("�˳�");
		miOnline = new MenuItem("����");
		miLevel = new MenuItem("����");
		miBuys = new MenuItem("æµ");
		miOpen.addActionListener(this);
		miExit.addActionListener(this);
		miOnline.addActionListener(this);
		miLevel.addActionListener(this);
		miBuys.addActionListener(this);
		
		popTray.add(miOpen);
		popTray.add(miExit);
		popTray.add(miOnline);
		popTray.add(miLevel);
		popTray.add(miBuys);
	}
	//��������ͼ��
	public void setTrayIcon(){
		Image image = new ImageIcon("images/tubiao.png").getImage();
		trayIcon = new TrayIcon(image,"QQ2016",popTray);
		//ϵͳ�Զ�����ͼ��Ĵ�С
		trayIcon.setImageAutoSize(true);
	}
}
