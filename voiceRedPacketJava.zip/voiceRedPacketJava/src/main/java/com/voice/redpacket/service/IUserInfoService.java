package com.voice.redpacket.service;

import com.voice.redpacket.domain.UserAmountRecords;
import com.voice.redpacket.domain.UserInfo;

import java.util.List;

/**
 * Created by ZhaoYuJie on 2018/1/10.
 */
public interface IUserInfoService {
    void save(UserInfo userInfo);

    UserInfo getUserInfoByUnionId(String unionId);

    UserInfo getUserInfoByOpenId(String openId);

    void updateSelective(UserInfo userInfo);

    List<UserAmountRecords> findUserAmountRecords(String openId);
}
